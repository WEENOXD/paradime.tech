import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.paradime.monroe',
  appName: 'Monroe Beta',
  webDir: 'dist'
};

export default config;
