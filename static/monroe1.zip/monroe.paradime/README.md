# Monroe Beta

**AI-powered lead generation and sales automation CRM**

A professional desktop and mobile application for finding, managing, and qualifying business leads using multiple data sources including Google Places API and OpenStreetMap.

Built with Electron (desktop) and Capacitor (mobile) - runs as a standalone program on Windows, macOS, and iOS.

## Features

### Lead Generation
- 🔍 **Multi-source Data Collection** - Google Places API (New) + OpenStreetMap/Overpass
- 🗺️ **Interactive Map Search** - Draw rectangles on map to define search areas
- 🎯 **Smart Filtering** - Target specific business types with quality scoring
- 🔄 **Automatic Deduplication** - Remove duplicate leads intelligently
- 🌐 **Website Scraping** - Extract emails, phones, and social links from websites
- 📊 **Data Quality Scoring** - Automatic quality assessment (0-100 scale)

### Core Functionality
- 🗺️ **Interactive Map** - Visualize leads on a map powered by Leaflet and OpenStreetMap
- 📋 **Lead Management** - Full CRUD operations with status tracking and notes
- 📞 **Call Tracking** - "Already Dialed" feature to track contacted leads
- 🔍 **Advanced Filters** - Filter by business type, status, state, and more
- 📊 **CSV Import/Export** - Easily migrate data in and out
- 🤖 **AI Assistant** - OpenAI-powered conversation assistant for lead qualification
- 💾 **Local-First Storage** - All data stored locally in IndexedDB

### UI/UX
- 🎨 **Multiple Theme System**:
  - **Classic Grey** (default) - Windows classic aesthetic
  - **Windows XP Blue** - Early 2000s XP blue theme
  - **Dark Mode** - Professional dark interface
  - **Black** - Pure black theme for maximum contrast
  - **Midnight Blue** - Deep blue dark theme
  - **Olive Green** - Retro green theme
- ⌨️ **Keyboard Shortcuts**:
  - `/` - Focus search
  - `Esc` - Close drawers and clear focus
- 📱 **Responsive Layout** - Top bar, sidebar, map, list, and status bar

### Lead Details
- 📞 **Click-to-Call** - Direct tel: links
- 📝 **Auto-saving Notes** - Notes save automatically as you type
- 🏷️ **Status Management** - Quick status updates with visual chips
- ⏰ **Follow-up Scheduling** - Set follow-up dates with quick actions
- ✨ **Script Generation** - AI-powered call scripts tailored to each lead

## Getting Started

### Prerequisites
- Node.js 18+ installed
- OpenAI API key (optional, for call script generation)

### Running the Desktop App

#### Development Mode (with DevTools)

1. Navigate to the project directory:
   ```bash
   cd lead-map-workspace
   ```

2. Install dependencies (if not already done):
   ```bash
   npm install
   ```

3. Start the desktop application:
   ```bash
   npm run electron:dev
   ```

The app will launch in a native window with DevTools open for debugging.

#### Build Standalone Executable

To create a distributable installer/executable:

**Windows:**
```bash
npm run electron:build:win
```
Creates installer and portable .exe in `release/` folder

**Mac:**
```bash
npm run electron:build:mac
```
Creates .dmg and .zip in `release/` folder

**Linux:**
```bash
npm run electron:build:linux
```
Creates AppImage and .deb in `release/` folder

**All platforms:**
```bash
npm run electron:build
```

### First Run

On first launch, the app will:
- Initialize the local IndexedDB database
- Load 15 real business leads across various US cities
- Be ready to use immediately!

## Usage Guide

### Setting Up API Keys

#### Google Places API (Required for Lead Search)

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create or select a project
3. Enable **"Places API (New)"** (not the legacy "Places API")
4. Go to Credentials > Create Credentials > API Key
5. (Recommended) Restrict key to Places API (New)
6. Click **⚙️ Settings** in Monroe
7. Paste your API key into the Google Places API field
8. Click **Save Settings**

**Important:** Enable "Places API (New)", not the legacy "Places API". The old API is deprecated and not supported.

#### OpenAI API (Optional for AI Features)

1. Go to [OpenAI Platform](https://platform.openai.com/)
2. Create API key and add billing information
3. Click **⚙️ Settings** in Monroe
4. Enter your OpenAI API key
5. Click **Save Settings**

Your API keys are stored **locally** in IndexedDB and never sent anywhere except to the respective API providers.

### Managing Leads

#### Adding Leads
1. Click **+ Add Lead** in the sidebar
2. Fill in required fields (Business Name, Phone, City, State, Lat/Lng)
3. Submit the form

#### Viewing/Editing Leads
- Click any lead in the list or map marker
- Lead detail drawer opens on the right
- Edit notes (auto-saves after 1 second)
- Update status with quick chips
- Set follow-up dates

#### Generating Call Scripts
1. Open a lead detail drawer
2. Click **✨ Generate Call Script**
3. Wait for AI to generate a personalized script
4. Script includes:
   - 20-30 second opener
   - 3 discovery questions
   - 2 tailored value points
   - Objection handling
   - Next-step close

### Importing/Exporting Data

#### Export CSV
1. Apply any filters you want (optional)
2. Click **📤 Export CSV**
3. Downloads filtered leads as CSV

#### Import CSV
1. Click **📥 Import CSV**
2. Select your CSV file
3. File is validated and imported

#### Sample CSV
Click **📄 Sample CSV** to download a template with the correct format.

### Filtering Leads

Use the sidebar filters to narrow down leads:
- **Search** - Search by name, city, state, type, or phone
- **Business Type** - Filter by industry
- **Status** - Filter by call status
- **State** - Filter by state
- **Website** - Filter by presence of website
- **Clear Filters** - Reset all filters

### Keyboard Shortcuts

- **`/`** - Jump to search box
- **`Esc`** - Close lead detail drawer and blur search
- **`F12`** - Toggle DevTools (in development mode)
- **`Ctrl+R` / `Cmd+R`** - Reload app (in development mode)

## Data Model

Each lead contains:
- **Business Info**: name, type, owner/manager name
- **Contact**: phone number, website URL
- **Location**: address, city, state, ZIP, coordinates (lat/lng)
- **CRM**: notes, status, last contacted date, next follow-up date
- **Metadata**: ID, created/updated timestamps

### Status Values
- `NotContacted` - Not yet called
- `Called` - Successfully reached
- `LeftVM` - Left voicemail
- `Interested` - Expressed interest
- `FollowUp` - Needs follow-up
- `Closed` - Deal closed
- `NotAFit` - Not a good fit

## Building for Production

```bash
npm run build
```

The production build will be in the `dist/` folder. You can serve it with any static file server:

```bash
npm install -g serve
serve -s dist
```

## Technology Stack

- **Desktop Framework**: Electron 39
- **Mobile Framework**: Capacitor 8
- **Frontend**: React 19 + TypeScript + Vite 7
- **Build Tool**: electron-builder 26
- **Map**: Leaflet + React Leaflet + OpenStreetMap
- **Database**: IndexedDB via Dexie.js (persistent local storage)
- **Styling**: Tailwind CSS 4 + Custom Windows XP theme
- **APIs**: Google Places API (New), OpenStreetMap/Overpass, OpenAI
- **Data**: PapaParse for CSV, Cheerio for web scraping

## Included Sample Leads

The app comes pre-loaded with 15 real businesses:
- Blue Bottle Coffee (Oakland, CA)
- Sweetgreen (New York, NY)
- Torchy's Tacos (Austin, TX)
- Massage Envy (Phoenix, AZ)
- Orangetheory Fitness (Fort Lauderdale, FL)
- Peet's Coffee (Berkeley, CA)
- Jiffy Lube (Houston, TX)
- Keller Williams Realty (Austin, TX)
- Planet Fitness (Hampton, NH)
- The UPS Store (La Jolla, CA)
- Guitar Center (Nashville, TN)
- Roto-Rooter Plumbing (Cincinnati, OH)
- Anytime Fitness (Blaine, MN)
- Ace Hardware (Oak Brook, IL)
- PetSmart (Phoenix, AZ)

All with real phone numbers, websites, and accurate GPS coordinates.

## Project Structure

```
lead-map-workspace/
├── electron/
│   ├── main.js              # Electron main process
│   └── preload.js           # Preload script (security)
├── src/
│   ├── components/
│   │   ├── ui/              # Reusable UI components
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Select.tsx
│   │   │   └── Modal.tsx
│   │   ├── LeadMap.tsx      # Map component
│   │   ├── LeadList.tsx     # Lead table
│   │   ├── LeadDetail.tsx   # Lead drawer
│   │   └── Settings.tsx     # Settings modal
│   ├── db/
│   │   ├── database.ts      # Dexie schema
│   │   └── seedData.ts      # Real business data
│   ├── types/
│   │   └── lead.ts          # TypeScript types
│   ├── utils/
│   │   └── csv.ts           # CSV import/export
│   ├── App.tsx              # Main app
│   ├── main.tsx             # Entry point
│   └── index.css            # Webcore theme + Tailwind
├── dist/                    # Built app (after npm run build)
├── release/                 # Installers (after electron:build)
├── package.json
├── vite.config.ts
├── tailwind.config.js
└── README.md
```

## Notes

- **True Desktop Application** - Runs as a native program, not a web server
- **No Backend Required** - Everything runs locally on your machine
- **Privacy First** - All data stays on your computer in IndexedDB
- **Offline Capable** - Works without internet (except map tiles and AI features)
- **No Dependencies on External Services** - Only OpenAI for script generation (optional)
- **Cross-Platform** - Works on Windows, macOS, and Linux
- **Portable Build** - Windows users can use the portable .exe (no installation required)

## Support

For issues or questions, check the DevTools console (automatically open in dev mode). Common issues:

- **Map not loading**: Check network connection (OpenStreetMap tiles require internet)
- **Script generation fails**: Verify OpenAI API key in Settings
- **CSV import fails**: Check CSV format matches sample
- **App won't start**: Ensure Node.js 18+ is installed and run `npm install`
- **Build fails**: Check that all dependencies are installed correctly

## License

MIT License - feel free to use and modify as needed!

---

Built with Claude Code 🤖
