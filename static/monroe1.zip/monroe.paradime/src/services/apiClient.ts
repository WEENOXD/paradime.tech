import axios, { AxiosError } from 'axios';
import type { AxiosInstance } from 'axios';
import axiosRetry from 'axios-retry';

/**
 * Creates an axios instance with retry logic and timeout handling
 */
export function createAPIClient(config: {
  baseURL?: string;
  timeout?: number;
  maxRetries?: number;
  retryDelay?: number;
}): AxiosInstance {
  const { baseURL, timeout = 30000, maxRetries = 3, retryDelay = 1000 } = config;

  const client = axios.create({
    baseURL,
    timeout,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Configure retry logic
  axiosRetry(client, {
    retries: maxRetries,
    retryDelay: (retryCount) => {
      // Exponential backoff: 1s, 2s, 4s
      return retryDelay * Math.pow(2, retryCount - 1);
    },
    retryCondition: (error: AxiosError) => {
      // Retry on network errors or 5xx server errors
      if (!error.response) return true; // Network error

      const status = error.response.status;
      // Retry on: 429 (rate limit), 500-504 (server errors)
      return status === 429 || (status >= 500 && status <= 504);
    },
    onRetry: (retryCount, error, requestConfig) => {
      console.log(
        `Retry attempt ${retryCount} for ${requestConfig.url}`,
        error.message
      );
    },
  });

  return client;
}

/**
 * Checks if an error is a quota/rate limit error
 */
export function isQuotaError(error: any): boolean {
  if (axios.isAxiosError(error)) {
    const status = error.response?.status;
    return status === 429 || status === 403;
  }
  return false;
}

/**
 * Checks if an error is retryable
 */
export function isRetryableError(error: any): boolean {
  if (axios.isAxiosError(error)) {
    if (!error.response) return true; // Network error

    const status = error.response?.status;
    return status === 429 || (status >= 500 && status <= 504);
  }
  return false;
}

/**
 * Extracts error message from various error types
 */
export function getErrorMessage(error: any): string {
  if (axios.isAxiosError(error)) {
    if (error.response?.data?.error?.message) {
      return error.response.data.error.message;
    }
    if (error.response?.data?.message) {
      return error.response.data.message;
    }
    if (error.response?.statusText) {
      return error.response.statusText;
    }
    if (error.message) {
      return error.message;
    }
  }

  if (error instanceof Error) {
    return error.message;
  }

  return 'Unknown error occurred';
}

/**
 * Retry function with exponential backoff
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: {
    maxRetries?: number;
    baseDelay?: number;
    onRetry?: (attempt: number, error: any) => void;
  } = {}
): Promise<T> {
  const { maxRetries = 3, baseDelay = 1000, onRetry } = options;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (attempt === maxRetries) {
        throw error; // Last attempt failed
      }

      if (!isRetryableError(error)) {
        throw error; // Non-retryable error
      }

      const delay = baseDelay * Math.pow(2, attempt - 1);
      if (onRetry) {
        onRetry(attempt, error);
      }

      await sleep(delay);
    }
  }

  throw new Error('All retry attempts failed');
}

/**
 * Sleep utility
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Rate limiter using token bucket algorithm
 */
export class RateLimiter {
  private tokens: number;
  private lastRefill: number;
  private readonly maxTokens: number;
  private readonly refillRate: number; // tokens per second

  constructor(maxCallsPerSecond: number) {
    this.maxTokens = maxCallsPerSecond;
    this.tokens = maxCallsPerSecond;
    this.refillRate = maxCallsPerSecond;
    this.lastRefill = Date.now();
  }

  private refill() {
    const now = Date.now();
    const timePassed = (now - this.lastRefill) / 1000; // seconds
    const tokensToAdd = timePassed * this.refillRate;

    this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
    this.lastRefill = now;
  }

  async waitForToken(): Promise<void> {
    this.refill();

    if (this.tokens >= 1) {
      this.tokens -= 1;
      return;
    }

    // Need to wait
    const tokensNeeded = 1 - this.tokens;
    const waitTime = (tokensNeeded / this.refillRate) * 1000; // milliseconds

    await sleep(waitTime);
    this.tokens = 0; // Consumed
  }

  async throttle<T>(fn: () => Promise<T>): Promise<T> {
    await this.waitForToken();
    return fn();
  }
}
