import axios from 'axios';
import * as cheerio from 'cheerio';

export interface ScrapedWebsiteData {
  emails: string[];
  phones: string[];
  socialLinks: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
    linkedin?: string;
  };
  hasContactForm: boolean;
  metaDescription?: string;
  businessHours?: string;
}

/**
 * Scrapes a business website for additional contact information
 */
export async function scrapeWebsite(url: string): Promise<ScrapedWebsiteData | null> {
  try {
    // Normalize URL
    if (!url.startsWith('http')) {
      url = 'https://' + url;
    }

    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      maxRedirects: 5,
    });

    const $ = cheerio.load(response.data);
    const text = $('body').text();

    // Extract emails
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const emails = [...new Set(text.match(emailRegex) || [])].filter(
      (email) => !email.includes('example.com') && !email.includes('sentry.io')
    );

    // Extract phone numbers (US format)
    const phoneRegex = /(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\d{3}[-.\s]\d{3}[-.\s]\d{4})/g;
    const phones = [...new Set(text.match(phoneRegex) || [])];

    // Extract social media links
    const socialLinks: ScrapedWebsiteData['socialLinks'] = {};

    $('a[href*="facebook.com"]').each((_, el) => {
      const href = $(el).attr('href');
      if (href && !socialLinks.facebook) {
        socialLinks.facebook = href;
      }
    });

    $('a[href*="instagram.com"]').each((_, el) => {
      const href = $(el).attr('href');
      if (href && !socialLinks.instagram) {
        socialLinks.instagram = href;
      }
    });

    $('a[href*="twitter.com"], a[href*="x.com"]').each((_, el) => {
      const href = $(el).attr('href');
      if (href && !socialLinks.twitter) {
        socialLinks.twitter = href;
      }
    });

    $('a[href*="linkedin.com"]').each((_, el) => {
      const href = $(el).attr('href');
      if (href && !socialLinks.linkedin) {
        socialLinks.linkedin = href;
      }
    });

    // Check for contact form
    const hasContactForm =
      $('form[action*="contact"]').length > 0 ||
      $('form').filter((_, el) => {
        const formText = $(el).text().toLowerCase();
        return formText.includes('contact') || formText.includes('message');
      }).length > 0;

    // Get meta description
    const metaDescription = $('meta[name="description"]').attr('content');

    // Try to extract business hours
    let businessHours: string | undefined;
    const hoursKeywords = ['hours', 'open', 'monday', 'tuesday', 'am', 'pm'];
    $('*').each((_, el) => {
      const elText = $(el).text();
      if (hoursKeywords.some(keyword => elText.toLowerCase().includes(keyword))) {
        const hourText = elText.trim();
        if (hourText.length > 20 && hourText.length < 500) {
          businessHours = hourText;
          return false; // Break
        }
      }
    });

    return {
      emails: emails.slice(0, 5), // Limit to 5 emails
      phones: phones.slice(0, 3), // Limit to 3 phones
      socialLinks,
      hasContactForm,
      metaDescription,
      businessHours,
    };
  } catch (error: any) {
    console.warn(`Failed to scrape ${url}:`, error.message);
    return null;
  }
}

/**
 * Enriches a lead with scraped website data
 */
export async function enrichLeadWithWebsiteData(
  lead: { website_url?: string; phone_number?: string },
  onProgress?: (message: string) => void
): Promise<ScrapedWebsiteData | null> {
  if (!lead.website_url) {
    return null;
  }

  onProgress?.(`Scraping ${lead.website_url}...`);

  try {
    const scrapedData = await scrapeWebsite(lead.website_url);

    if (scrapedData) {
      onProgress?.(`✓ Found ${scrapedData.emails.length} emails, ${scrapedData.phones.length} phones`);
    }

    return scrapedData;
  } catch (error) {
    onProgress?.(`⚠️ Failed to scrape website`);
    return null;
  }
}
