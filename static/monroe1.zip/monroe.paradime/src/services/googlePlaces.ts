import type { Bounds, NormalizedBusiness } from '../types/apiTypes';
import { formatPhone, calculateQualityScore } from '../utils/validation';
import { createAPIClient, RateLimiter } from './apiClient';
import type { AxiosInstance } from 'axios';

/**
 * Google Places API Service
 * Primary data source for real business information
 */
export class GooglePlacesService {
  private client: AxiosInstance;
  private rateLimiter: RateLimiter;

  // Business types to search for
  private readonly businessTypes = [
    'restaurant',
    'cafe',
    'bar',
    'bakery',
    'store',
    'hardware_store',
    'florist',
    'plumber',
    'electrician',
    'general_contractor',
    'roofing_contractor',
    'dentist',
    'doctor',
    'gym',
    'beauty_salon',
    'hair_care',
    'spa',
    'real_estate_agency',
    'car_repair',
    'car_dealer',
    'car_wash',
    'accounting',
    'lawyer',
    'insurance_agency',
  ];

  constructor(apiKey: string) {
    this.client = createAPIClient({
      baseURL: 'https://places.googleapis.com',
      timeout: 15000,
    });

    // Set custom headers for new Places API
    this.client.defaults.headers.common['X-Goog-Api-Key'] = apiKey;
    this.client.defaults.headers.common['X-Goog-FieldMask'] = 'places.id,places.displayName,places.formattedAddress,places.location,places.types,places.nationalPhoneNumber,places.internationalPhoneNumber,places.websiteUri,places.addressComponents';

    this.rateLimiter = new RateLimiter(10); // 10 requests per second max
  }

  /**
   * Searches for businesses within the specified bounds
   */
  async searchBusinesses(bounds: Bounds, maxResults: number = 200): Promise<NormalizedBusiness[]> {
    const businesses: NormalizedBusiness[] = [];

    try {
      // Calculate center point for search
      const center = {
        lat: bounds.center.lat,
        lng: bounds.center.lng,
      };

      // Calculate radius (approximate)
      const radius = this.calculateRadius(bounds);

      console.log(`Google Places: Searching within ${radius}m radius of ${center.lat}, ${center.lng}`);

      // Search for multiple business types to get variety
      const typesToSearch = this.businessTypes.slice(0, 10); // Limit to avoid too many API calls

      for (const type of typesToSearch) {
        if (businesses.length >= maxResults) break;

        try {
          const results = await this.searchByType(center.lat, center.lng, radius, type);
          businesses.push(...results);
          console.log(`Google Places: Found ${results.length} businesses for type "${type}"`);
        } catch (error: any) {
          const topLevelError = {
            message: error.message,
            status: error.response?.status,
            statusText: error.response?.statusText,
            data: error.response?.data,
            code: error.code,
          };
          console.error(`Google Places: Failed to search type "${type}":`, JSON.stringify(topLevelError, null, 2));
          // Continue with other types
        }
      }

      return businesses.slice(0, maxResults);
    } catch (error) {
      console.error('Google Places search failed:', error);
      throw error;
    }
  }

  /**
   * Searches for a specific business type
   */
  private async searchByType(
    lat: number,
    lng: number,
    radius: number,
    type: string
  ): Promise<NormalizedBusiness[]> {
    return this.rateLimiter.throttle(async () => {
      try {
        // New Places API uses POST with JSON body
        const response = await this.client.post('/v1/places:searchNearby', {
          includedTypes: [type],
          maxResultCount: 20,
          locationRestriction: {
            circle: {
              center: {
                latitude: lat,
                longitude: lng,
              },
              radius: Math.min(radius, 50000), // Max 50km
            },
          },
        });

        console.log(`Google Places (New API) response for ${type}:`, {
          placesCount: response.data.places?.length || 0,
          firstPlace: response.data.places?.[0]?.displayName,
        });

        if (!response.data.places || response.data.places.length === 0) {
          console.log(`Zero results for type "${type}"`);
          return [];
        }

        // New API returns full data immediately, no need for details call
        const businesses: NormalizedBusiness[] = [];

        for (const place of response.data.places) {
          try {
            // DEBUG: Log first place to see structure
            if (businesses.length === 0) {
              console.log('First place raw data:', JSON.stringify(place, null, 2));
            }

            const normalized = this.normalizePlaceToLead(place);
            if (normalized) {
              // DEBUG: Log first normalized result
              if (businesses.length === 0) {
                console.log('First normalized business:', JSON.stringify({
                  name: normalized.business_name,
                  address: normalized.address_line1,
                  city: normalized.city,
                  state: normalized.state,
                  zip: normalized.zip,
                  phone: normalized.phone_number,
                  website: normalized.website_url,
                }, null, 2));
              }
              businesses.push(normalized);
            }
          } catch (error) {
            console.warn(`Failed to normalize place:`, error);
            // Continue with other places
          }
        }

        return businesses;
      } catch (error: any) {
        const errorDetails = {
          message: error.message,
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data,
        };
        console.error('Google Places (New API) error:', JSON.stringify(errorDetails, null, 2));

        if (error.response?.status === 403) {
          const errorMsg = 'Google Places API: Permission denied. Enable "Places API (New)" in Google Cloud Console';
          console.error(errorMsg);
          alert(errorMsg);
          throw new Error(errorMsg);
        }

        if (error.response?.status === 429) {
          throw new Error('Google Places quota exceeded');
        }
        throw error;
      }
    });
  }

  /**
   * REMOVED: getPlaceDetails - New API returns all data in search, no details call needed
   */

  /**
   * Normalizes Google Place data to NormalizedBusiness format (New Places API)
   */
  private normalizePlaceToLead(place: any): NormalizedBusiness {
    // New API format uses different field names
    const addressComponents = place.addressComponents || [];

    const business: NormalizedBusiness = {
      external_id: place.id || '',
      data_source: 'google_places',
      business_name: place.displayName?.text || place.displayName || 'Unknown Business',
      business_type: this.mapGoogleTypeToBusinessType(place.types),
      phone_number: formatPhone(
        place.nationalPhoneNumber || place.internationalPhoneNumber
      ),
      address_line1: this.extractStreetAddress(place.formattedAddress, addressComponents),
      city: this.extractAddressComponent(addressComponents, 'locality'),
      state: this.extractAddressComponent(addressComponents, 'administrative_area_level_1', true),
      zip: this.extractAddressComponent(addressComponents, 'postal_code'),
      lat: place.location?.latitude || 0,
      lng: place.location?.longitude || 0,
      website_url: place.websiteUri,
      raw_categories: place.types || [],
      notes: '',
      data_quality_score: 0, // Will be calculated below
    };

    // Calculate quality score
    business.data_quality_score = calculateQualityScore(business);

    return business;
  }

  /**
   * Maps Google place types to our business type
   */
  private mapGoogleTypeToBusinessType(types: string[] | undefined): string {
    if (!types || types.length === 0) return 'Unknown';

    const typeMap: Record<string, string> = {
      restaurant: 'Restaurant',
      cafe: 'Cafe',
      bar: 'Bar',
      bakery: 'Bakery',
      store: 'Retail Shop',
      hardware_store: 'Hardware Store',
      florist: 'Florist',
      plumber: 'Plumber',
      electrician: 'Electrician',
      general_contractor: 'Contractor',
      roofing_contractor: 'Roofer',
      dentist: 'Dentist',
      doctor: 'Doctor',
      gym: 'Gym',
      beauty_salon: 'Salon',
      hair_care: 'Hair Salon',
      spa: 'Spa',
      real_estate_agency: 'Real Estate',
      car_repair: 'Auto Repair',
      car_dealer: 'Auto Dealer',
      car_wash: 'Car Wash',
      accounting: 'Accountant',
      lawyer: 'Law Firm',
      insurance_agency: 'Insurance Agency',
    };

    // Find the first matching type
    for (const type of types) {
      if (typeMap[type]) {
        return typeMap[type];
      }
    }

    // Return first type capitalized if no match
    return types[0].replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  }

  /**
   * Extracts a specific address component (New Places API format)
   */
  private extractAddressComponent(
    components: any[],
    type: string,
    useShortName: boolean = false
  ): string {
    // New API uses 'types' array
    const component = components.find((c) => c.types?.includes(type));
    if (!component) return '';
    return useShortName ? (component.shortText || component.longText) : (component.longText || component.shortText);
  }

  /**
   * Extracts street address from formatted address
   */
  private extractStreetAddress(
    formattedAddress: string | undefined,
    components: any[]
  ): string {
    if (!formattedAddress) return '';

    // Try to extract from address components first
    const streetNumber = this.extractAddressComponent(components, 'street_number');
    const route = this.extractAddressComponent(components, 'route');

    if (streetNumber && route) {
      return `${streetNumber} ${route}`;
    }

    // Fallback: take first line of formatted address
    const firstLine = formattedAddress.split(',')[0];
    return firstLine || '';
  }

  /**
   * Calculates approximate radius in meters from bounds
   */
  private calculateRadius(bounds: Bounds): number {
    const latDiff = bounds.north - bounds.south;
    const lngDiff = bounds.east - bounds.west;

    // Approximate: 1 degree latitude ≈ 111km
    const latDistance = latDiff * 111000; // meters
    const lngDistance = lngDiff * 111000 * Math.cos((bounds.center.lat * Math.PI) / 180);

    // Use half the diagonal as radius
    const diagonal = Math.sqrt(latDistance ** 2 + lngDistance ** 2);
    return Math.min(diagonal / 2, 50000); // Max 50km radius (Google Places limit)
  }
}
