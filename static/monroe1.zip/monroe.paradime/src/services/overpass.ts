import type { Bounds, NormalizedBusiness, OverpassResponse, OverpassElement } from '../types/apiTypes';
import { formatPhone, calculateQualityScore } from '../utils/validation';
import { createAPIClient, RateLimiter } from './apiClient';
import type { AxiosInstance } from 'axios';

/**
 * Overpass API / OpenStreetMap Service
 * Tertiary (fallback) data source - free but limited phone number coverage
 */
export class OverpassService {
  private client: AxiosInstance;
  private rateLimiter: RateLimiter;
  private readonly baseURL = 'https://overpass-api.de/api/interpreter';

  constructor() {
    this.client = createAPIClient({
      timeout: 30000, // OSM queries can be slow
    });

    // OSM recommends max 2 requests/second
    this.rateLimiter = new RateLimiter(1);
  }

  /**
   * Searches for businesses within the specified bounds
   */
  async searchBusinesses(bounds: Bounds, maxResults: number = 200): Promise<NormalizedBusiness[]> {
    try {
      console.log(`Overpass: Searching businesses in bounds`);

      const query = this.buildOverpassQuery(bounds);
      const response = await this.executeQuery(query);

      if (!response.elements || response.elements.length === 0) {
        console.log('Overpass: No businesses found');
        return [];
      }

      console.log(`Overpass: Found ${response.elements.length} potential businesses`);

      // Filter and normalize results
      const businesses = response.elements
        .filter((element) => this.isValidBusiness(element))
        .map((element) => this.normalizeOSMElement(element))
        .filter((business): business is NormalizedBusiness => business !== null)
        .slice(0, maxResults);

      console.log(`Overpass: Normalized ${businesses.length} valid businesses`);

      return businesses;
    } catch (error) {
      console.error('Overpass search failed:', error);
      throw error;
    }
  }

  /**
   * Executes an Overpass QL query
   */
  private async executeQuery(query: string): Promise<OverpassResponse> {
    return this.rateLimiter.throttle(async () => {
      try {
        const response = await this.client.post<OverpassResponse>(
          this.baseURL,
          `data=${encodeURIComponent(query)}`,
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        );

        return response.data;
      } catch (error: any) {
        if (error.response?.status === 429) {
          throw new Error('Overpass rate limit exceeded');
        }
        throw error;
      }
    });
  }

  /**
   * Builds an Overpass QL query for the specified bounds
   */
  private buildOverpassQuery(bounds: Bounds): string {
    const bbox = `${bounds.south},${bounds.west},${bounds.north},${bounds.east}`;

    // Query for nodes and ways with business-related tags
    // Filter for entities that have phone numbers (since that's critical for cold calling)
    return `
      [out:json][timeout:25];
      (
        // Amenities with phone
        node["amenity"]["phone"](${bbox});
        way["amenity"]["phone"](${bbox});

        // Shops with phone
        node["shop"]["phone"](${bbox});
        way["shop"]["phone"](${bbox});

        // Offices with phone
        node["office"]["phone"](${bbox});
        way["office"]["phone"](${bbox});

        // Craft businesses with phone
        node["craft"]["phone"](${bbox});
        way["craft"]["phone"](${bbox});

        // Also check contact:phone variant
        node["amenity"]["contact:phone"](${bbox});
        way["amenity"]["contact:phone"](${bbox});
        node["shop"]["contact:phone"](${bbox});
        way["shop"]["contact:phone"](${bbox});
      );
      out center;
    `.trim();
  }

  /**
   * Checks if an OSM element is a valid business
   */
  private isValidBusiness(element: OverpassElement): boolean {
    const tags = element.tags;
    if (!tags) return false;

    // Must have a name
    if (!tags.name && !tags['name:en']) return false;

    // Must have coordinates
    const hasCoords = (element.lat && element.lon) || element.center;
    if (!hasCoords) return false;

    // Must have a phone number (critical for cold calling)
    const hasPhone = tags.phone || tags['contact:phone'];
    if (!hasPhone) return false;

    // Must be a business type we care about
    const hasBusinessTag = tags.amenity || tags.shop || tags.office || tags.craft;
    if (!hasBusinessTag) return false;

    return true;
  }

  /**
   * Normalizes OSM element to NormalizedBusiness format
   */
  private normalizeOSMElement(element: OverpassElement): NormalizedBusiness | null {
    const tags = element.tags;
    if (!tags) return null;

    // Get coordinates
    const lat = element.lat || element.center?.lat;
    const lng = element.lon || element.center?.lon;

    if (!lat || !lng) return null;

    const business: NormalizedBusiness = {
      external_id: `osm-${element.type}-${element.id}`,
      data_source: 'overpass',
      business_name: tags.name || tags['name:en'] || 'Unknown Business',
      business_type: this.mapOSMTagsToBusinessType(tags),
      phone_number: formatPhone(tags.phone || tags['contact:phone']),
      address_line1: this.buildAddress(tags),
      city: tags['addr:city'] || '',
      state: tags['addr:state'] || '',
      zip: tags['addr:postcode'] || '',
      lat,
      lng,
      website_url: tags.website || tags['contact:website'],
      raw_categories: this.extractCategories(tags),
      notes: 'Source: OpenStreetMap',
      data_quality_score: 0, // Will be calculated below
    };

    // Calculate quality score
    business.data_quality_score = calculateQualityScore(business);

    return business;
  }

  /**
   * Maps OSM tags to business type
   */
  private mapOSMTagsToBusinessType(tags: Record<string, string | undefined>): string {
    const amenityMap: Record<string, string> = {
      restaurant: 'Restaurant',
      cafe: 'Cafe',
      bar: 'Bar',
      fast_food: 'Fast Food',
      pub: 'Pub',
      dentist: 'Dentist',
      doctors: 'Doctor',
      clinic: 'Clinic',
      pharmacy: 'Pharmacy',
      fuel: 'Gas Station',
      car_wash: 'Car Wash',
      car_repair: 'Auto Repair',
    };

    const shopMap: Record<string, string> = {
      bakery: 'Bakery',
      convenience: 'Convenience Store',
      supermarket: 'Supermarket',
      hardware: 'Hardware Store',
      florist: 'Florist',
      beauty: 'Beauty Shop',
      hairdresser: 'Hair Salon',
      car: 'Auto Dealer',
      car_repair: 'Auto Repair',
    };

    const officeMap: Record<string, string> = {
      accountant: 'Accountant',
      lawyer: 'Law Firm',
      insurance: 'Insurance Agency',
      estate_agent: 'Real Estate',
      company: 'Office',
    };

    const craftMap: Record<string, string> = {
      plumber: 'Plumber',
      electrician: 'Electrician',
      carpenter: 'Carpenter',
      painter: 'Painter',
      roofer: 'Roofer',
    };

    if (tags.amenity && amenityMap[tags.amenity]) {
      return amenityMap[tags.amenity];
    }

    if (tags.shop && shopMap[tags.shop]) {
      return shopMap[tags.shop];
    }

    if (tags.office && officeMap[tags.office]) {
      return officeMap[tags.office];
    }

    if (tags.craft && craftMap[tags.craft]) {
      return craftMap[tags.craft];
    }

    // Fallback to tag value capitalized
    const primaryTag = tags.amenity || tags.shop || tags.office || tags.craft;
    if (primaryTag) {
      return primaryTag.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
    }

    return 'Unknown';
  }

  /**
   * Builds address from OSM address tags
   */
  private buildAddress(tags: Record<string, string | undefined>): string {
    const parts: string[] = [];

    if (tags['addr:housenumber']) {
      parts.push(tags['addr:housenumber']);
    }

    if (tags['addr:street']) {
      parts.push(tags['addr:street']);
    }

    return parts.join(' ');
  }

  /**
   * Extracts category tags for reference
   */
  private extractCategories(tags: Record<string, string | undefined>): string[] {
    const categories: string[] = [];

    if (tags.amenity) categories.push(tags.amenity);
    if (tags.shop) categories.push(tags.shop);
    if (tags.office) categories.push(tags.office);
    if (tags.craft) categories.push(tags.craft);

    return categories;
  }
}
