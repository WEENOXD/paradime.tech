import type { Bounds, NormalizedBusiness, SearchResult, DataSource } from '../types/apiTypes';
import type { Settings } from '../types/lead';
import { GooglePlacesService } from './googlePlaces';
import { OverpassService } from './overpass';
import { deduplicateLeads } from '../utils/deduplication';
import { filterTargetBusinesses, calculateTargetScore } from '../utils/businessTypeFilter';
import { enrichLeadWithWebsiteData } from './websiteScraper';
import { db } from '../db/database';

/**
 * Lead Orchestrator Service
 * Coordinates multi-source lead generation with intelligent fallback
 */
export class LeadOrchestrator {
  private googlePlaces?: GooglePlacesService;
  private overpass?: OverpassService;

  /**
   * Initializes services based on available API keys
   */
  initialize(settings: Settings) {
    // Debug: Log what we're initializing with
    console.log('LeadOrchestrator initialization:', {
      hasGooglePlacesKey: !!settings.google_places_api_key,
      googlePlacesKeyLength: settings.google_places_api_key?.length || 0,
      googlePlacesEnabled: settings.google_places_enabled,
      overpassEnabled: settings.overpass_enabled,
    });

    // Google Places (Primary)
    if (settings.google_places_api_key && settings.google_places_enabled !== false) {
      console.log('✅ Initializing Google Places service');
      this.googlePlaces = new GooglePlacesService(settings.google_places_api_key);
    } else {
      console.warn('❌ Google Places NOT initialized:', {
        hasKey: !!settings.google_places_api_key,
        enabled: settings.google_places_enabled,
      });
      this.googlePlaces = undefined;
    }

    // Overpass/OSM (Secondary - always available)
    if (settings.overpass_enabled !== false) {
      console.log('✅ Initializing Overpass service');
      this.overpass = new OverpassService();
    } else {
      console.warn('❌ Overpass NOT initialized');
      this.overpass = undefined;
    }
  }

  /**
   * Searches for leads using multi-source strategy with fallback
   */
  async searchLeads(
    bounds: Bounds,
    settings: Settings,
    onProgress?: (message: string) => void
  ): Promise<SearchResult> {
    this.initialize(settings);

    const maxResults = settings.max_results_per_search || 200;
    const minQualityScore = settings.min_data_quality_score || 60;

    const allBusinesses: NormalizedBusiness[] = [];
    const errors: Array<{ source: DataSource; error: Error }> = [];
    const successfulSources: DataSource[] = [];

    // Try Google Places first (best quality)
    if (this.googlePlaces) {
      try {
        onProgress?.('🔍 Searching Google Places API...');
        const googleResults = await this.googlePlaces.searchBusinesses(bounds, maxResults);
        allBusinesses.push(...googleResults);
        successfulSources.push('google_places');
        onProgress?.(`✅ Google Places: Found ${googleResults.length} businesses`);

        // If we got enough high-quality results, we can stop
        if (googleResults.length >= maxResults * 0.8) {
          onProgress?.('✅ Sufficient results from Google Places');
        }
      } catch (error: any) {
        errors.push({ source: 'google_places', error });
        onProgress?.(`⚠️ Google Places failed: ${error.message}`);
      }
    }

    // Try Overpass/OSM as fallback
    if (this.overpass && allBusinesses.length < maxResults * 0.5) {
      try {
        onProgress?.('🔍 Searching OpenStreetMap...');
        const neededResults = maxResults - allBusinesses.length;
        const osmResults = await this.overpass.searchBusinesses(bounds, neededResults);
        allBusinesses.push(...osmResults);
        successfulSources.push('overpass');
        onProgress?.(`✅ OpenStreetMap: Found ${osmResults.length} businesses`);
      } catch (error: any) {
        errors.push({ source: 'overpass', error });
        onProgress?.(`⚠️ OpenStreetMap failed: ${error.message}`);
      }
    }

    if (allBusinesses.length === 0) {
      const errorMessage = errors.length > 0
        ? `All sources failed: ${errors.map((e) => e.error.message).join(', ')}`
        : 'No API sources configured. Please add API keys in settings.';

      throw new Error(errorMessage);
    }

    // Filter by geographic bounds (ensure all businesses are actually in the rectangle)
    onProgress?.('📍 Filtering by geographic bounds...');
    const inBounds = allBusinesses.filter((business) => {
      return (
        business.lat >= bounds.south &&
        business.lat <= bounds.north &&
        business.lng >= bounds.west &&
        business.lng <= bounds.east
      );
    });
    const outOfBounds = allBusinesses.length - inBounds.length;
    if (outOfBounds > 0) {
      onProgress?.(`✅ Geographic filter: Removed ${outOfBounds} businesses outside your search area`);
    }

    // Filter by target business types
    onProgress?.('🎯 Filtering for target businesses...');
    const targetBusinesses = filterTargetBusinesses(inBounds);
    onProgress?.(
      `✅ Target filter: ${targetBusinesses.length}/${inBounds.length} match our customer profile`
    );

    // Filter by quality score
    onProgress?.('🔄 Filtering by quality score...');
    const qualityFiltered = targetBusinesses.filter(
      (b) => b.data_quality_score >= minQualityScore
    );

    onProgress?.(
      `✅ Quality filter: ${qualityFiltered.length}/${targetBusinesses.length} businesses meet minimum score of ${minQualityScore}`
    );

    // Deduplicate
    onProgress?.('🔄 Removing duplicates...');
    const existingLeads = await db.leads.toArray();
    const deduped = await deduplicateLeads(qualityFiltered, existingLeads);

    const duplicatesRemoved = qualityFiltered.length - deduped.length;
    onProgress?.(`✅ Deduplication: Removed ${duplicatesRemoved} duplicates`);

    // Enrich top leads with website scraping (limit to avoid too many requests)
    const leadsToEnrich = deduped.slice(0, 20); // Only scrape top 20 leads
    if (leadsToEnrich.length > 0 && leadsToEnrich.some(l => l.website_url)) {
      onProgress?.('🌐 Scraping websites for additional contact info...');

      let scrapedCount = 0;
      for (const lead of leadsToEnrich) {
        if (lead.website_url) {
          try {
            const scrapedData = await enrichLeadWithWebsiteData(lead);
            if (scrapedData) {
              // Add scraped data to the lead
              (lead as any).scraped_emails = scrapedData.emails;
              (lead as any).scraped_phones = scrapedData.phones;
              (lead as any).facebook_url = scrapedData.socialLinks.facebook;
              (lead as any).instagram_url = scrapedData.socialLinks.instagram;
              (lead as any).twitter_url = scrapedData.socialLinks.twitter;
              (lead as any).linkedin_url = scrapedData.socialLinks.linkedin;
              (lead as any).has_contact_form = scrapedData.hasContactForm;
              (lead as any).business_hours = scrapedData.businessHours;
              scrapedCount++;
            }
          } catch (error) {
            console.warn('Failed to scrape website:', error);
          }
        }
      }

      if (scrapedCount > 0) {
        onProgress?.(`✅ Scraped ${scrapedCount} websites for additional data`);
      }
    }

    // Calculate target scores and re-sort
    const scoredLeads = deduped.map(lead => {
      const targetScore = calculateTargetScore(
        lead.business_type,
        lead.business_name,
        !!lead.website_url,
        !!lead.phone_number
      );
      return { ...lead, targetScore };
    });

    // Sort by target score (highest first)
    scoredLeads.sort((a, b) => b.targetScore - a.targetScore);

    return {
      leads: scoredLeads.slice(0, maxResults),
      errors,
      successfulSources,
      totalFound: inBounds.length,
      totalAfterDedup: scoredLeads.length,
    };
  }

  /**
   * Gets a summary of available data sources
   */
  getAvailableSources(settings: Settings): {
    google_places: boolean;
    overpass: boolean;
  } {
    return {
      google_places: !!(settings.google_places_api_key && settings.google_places_enabled !== false),
      overpass: settings.overpass_enabled !== false,
    };
  }

  /**
   * Validates API keys by making test requests
   */
  async validateAPIKey(source: 'google_places', apiKey: string): Promise<boolean> {
    try {
      const testBounds: Bounds = {
        north: 37.8,
        south: 37.7,
        east: -122.3,
        west: -122.5,
        center: { lat: 37.75, lng: -122.4 },
      };

      if (source === 'google_places') {
        const service = new GooglePlacesService(apiKey);
        await service.searchBusinesses(testBounds, 1);
        return true;
      }

      return false;
    } catch (error) {
      console.error(`API key validation failed for ${source}:`, error);
      return false;
    }
  }
}

// Export singleton instance
export const leadOrchestrator = new LeadOrchestrator();
