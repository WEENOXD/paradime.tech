import { db } from './database';

async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 500
): Promise<T> {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      console.warn(`Attempt ${attempt}/${maxRetries} failed:`, error);
      if (attempt === maxRetries) {
        throw error;
      }
      await new Promise(resolve => setTimeout(resolve, delayMs * attempt));
    }
  }
  throw new Error('All retry attempts failed');
}

export async function initializeDatabase() {
  try {
    console.log('🔧 Opening database connection...');

    // Close database if already open (to avoid conflicts)
    if (db.isOpen()) {
      console.log('⚠️ Database already open, closing first...');
      db.close();
      // Wait a bit for cleanup
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // Ensure database is open with retry
    await retryOperation(async () => {
      try {
        if (!db.isOpen()) {
          await db.open();
        }
        // Verify it's actually open
        if (!db.isOpen()) {
          throw new Error('Database failed to open');
        }
        return true;
      } catch (err: any) {
        // If it's a version error or blocked error, try to close and reopen
        if (err.name === 'VersionError' || err.name === 'BlockedError') {
          console.warn(`Database ${err.name}, attempting to close and reopen...`);
          try {
            db.close();
            await new Promise(resolve => setTimeout(resolve, 200));
          } catch (closeErr) {
            // Ignore close errors
          }
          await db.open();
          return true;
        }
        throw err;
      }
    }, 5, 1000);

    console.log('✓ Database connection established');

    // Initialize default settings if not present
    const settingsCount = await retryOperation(async () => {
      try {
        return await db.settings.count();
      } catch (err: any) {
        console.warn('Settings count failed:', err);
        throw err;
      }
    });

    if (settingsCount === 0) {
      await retryOperation(async () => {
        try {
          await db.settings.add({
            id: 'default',
            openai_api_key: '',
            openai_model: 'gpt-4o-mini',
            script_tone: 'Professional',
            google_places_enabled: true,
            overpass_enabled: true,
          });
          return true;
        } catch (err: any) {
          // If it's a constraint error, the record might already exist
          if (err.name === 'ConstraintError') {
            console.log('Settings already exist (constraint error)');
            return true;
          }
          throw err;
        }
      });
      console.log('✓ Initialized default settings');
    } else {
      console.log('✓ Database already initialized');
    }

    return true;
  } catch (error: any) {
    console.error('❌ DATABASE ERROR:', error);
    console.error('Error name:', error?.name);
    console.error('Error message:', error?.message);
    console.error('Full error:', error);

    // Try to delete and recreate
    console.warn('⚠️ Attempting to delete and recreate database...');
    try {
      // Close first if open
      if (db.isOpen()) {
        db.close();
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      
      await db.delete();
      console.log('✓ Old database deleted');

      // Wait a bit before reopening
      await new Promise(resolve => setTimeout(resolve, 300));

      // Try opening again
      await db.open();
      await db.settings.add({
        id: 'default',
        openai_api_key: '',
        openai_model: 'gpt-4o-mini',
        script_tone: 'Professional',
        google_places_enabled: true,
        overpass_enabled: true,
      });
      console.log('✓ Database recreated successfully!');
      return true;
    } catch (recreateError: any) {
      console.error('❌ Failed to recreate database:', recreateError);
      console.error('Recreate error name:', recreateError?.name);
      console.error('Recreate error message:', recreateError?.message);

      const errorMsg = `DATABASE ERROR: Could not initialize IndexedDB.

The storage appears to be corrupted.

Error: ${error?.message || 'Unknown error'}

Possible solutions:
1. Close all other tabs/windows with this app open
2. Clear browser storage (IndexedDB)
3. Click "Reset Everything" button to clear storage and restart`;

      alert(errorMsg);
      return false;
    }
  }
}
