import Dexie, { type Table } from 'dexie';
import type { Lead, Settings } from '../types/lead';

export class LeadMapDatabase extends Dexie {
  leads!: Table<Lead>;
  settings!: Table<Settings>;

  constructor() {
    super('LeadMapDatabase');

    // Version 1: Original schema
    this.version(1).stores({
      leads: 'id, business_name, business_type, city, state, status, created_at, updated_at',
      settings: 'id'
    });

    // Version 2: Add new fields for multi-source scraping
    this.version(2).stores({
      leads: 'id, business_name, business_type, city, state, status, created_at, updated_at, phone_number, data_source, external_id',
      settings: 'id'
    }).upgrade(tx => {
      // Migrate existing leads to mark them as 'openai_legacy' source
      return tx.table('leads').toCollection().modify(lead => {
        if (!lead.data_source) {
          lead.data_source = 'openai_legacy';
          lead.data_quality_score = 30; // Mark as low quality (fake data)
        }
      });
    });

    // Version 3: Add scraped website data fields
    this.version(3).stores({
      leads: 'id, business_name, business_type, city, state, status, created_at, updated_at, phone_number, data_source, external_id, has_contact_form',
      settings: 'id'
    });

    // Version 4: Add already_dialed field for tracking dialed numbers
    this.version(4).stores({
      leads: 'id, business_name, business_type, city, state, status, created_at, updated_at, phone_number, data_source, external_id, has_contact_form, already_dialed',
      settings: 'id'
    }).upgrade(tx => {
      // Set all existing leads to not dialed by default
      return tx.table('leads').toCollection().modify(lead => {
        if (lead.already_dialed === undefined) {
          lead.already_dialed = false;
        }
      });
    });
  }
}

// Create database instance with error handling
export const db = new LeadMapDatabase();

// Handle database errors
db.on('blocked', () => {
  console.warn('Database blocked - another tab may be open');
});

db.on('versionchange', () => {
  console.warn('Database version changed - reloading');
  db.close();
});

// Don't auto-open - let initializeDatabase() handle it
