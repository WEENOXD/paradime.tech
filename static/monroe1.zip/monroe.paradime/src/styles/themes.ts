export interface Theme {
  name: string;
  colors: {
    background: string;
    titleBar: string;
    titleBarText: string;
    menuBar: string;
    toolbar: string;
    panel: string;
    panelBorder: string;
    button: string;
    buttonHover: string;
    buttonActive: string;
    input: string;
    inputBorder: string;
    text: string;
    textSecondary: string;
    accent: string;
    statusBar: string;
    windowBorder: string;
  };
}

export const themes: Record<string, Theme> = {
  'xp-blue': {
    name: 'Windows XP Blue',
    colors: {
      background: '#ece9d8',
      titleBar: 'linear-gradient(to bottom, #0997ff, #0053ee)',
      titleBarText: '#ffffff',
      menuBar: '#f0f0f0',
      toolbar: '#f0f0f0',
      panel: '#ffffff',
      panelBorder: '#999999',
      button: '#d4d0c8',
      buttonHover: '#e0e0e0',
      buttonActive: '#c0c0c0',
      input: '#ffffff',
      inputBorder: '#999999',
      text: '#000000',
      textSecondary: '#606060',
      accent: '#0053ee',
      statusBar: '#f0f0f0',
      windowBorder: '#0053ee',
    },
  },
  'classic-grey': {
    name: 'Classic Grey',
    colors: {
      background: '#c0c0c0',
      titleBar: 'linear-gradient(to bottom, #000080, #000060)',
      titleBarText: '#ffffff',
      menuBar: '#c0c0c0',
      toolbar: '#c0c0c0',
      panel: '#ffffff',
      panelBorder: '#808080',
      button: '#c0c0c0',
      buttonHover: '#d0d0d0',
      buttonActive: '#a0a0a0',
      input: '#ffffff',
      inputBorder: '#808080',
      text: '#000000',
      textSecondary: '#404040',
      accent: '#000080',
      statusBar: '#c0c0c0',
      windowBorder: '#808080',
    },
  },
  'dark-mode': {
    name: 'Dark Mode',
    colors: {
      background: '#1e1e1e',
      titleBar: 'linear-gradient(to bottom, #2d2d30, #1e1e1e)',
      titleBarText: '#ffffff',
      menuBar: '#2d2d30',
      toolbar: '#2d2d30',
      panel: '#252526',
      panelBorder: '#3e3e42',
      button: '#3e3e42',
      buttonHover: '#505052',
      buttonActive: '#2d2d30',
      input: '#3e3e42',
      inputBorder: '#555555',
      text: '#cccccc',
      textSecondary: '#999999',
      accent: '#0e639c',
      statusBar: '#007acc',
      windowBorder: '#3e3e42',
    },
  },
  'olive-green': {
    name: 'Olive Green',
    colors: {
      background: '#c8d4a8',
      titleBar: 'linear-gradient(to bottom, #6b8e23, #556b2f)',
      titleBarText: '#ffffff',
      menuBar: '#dae8c0',
      toolbar: '#dae8c0',
      panel: '#f5f8f0',
      panelBorder: '#8b9969',
      button: '#c8d4a8',
      buttonHover: '#d8e4b8',
      buttonActive: '#a8b488',
      input: '#ffffff',
      inputBorder: '#8b9969',
      text: '#1a2410',
      textSecondary: '#3d4a2d',
      accent: '#6b8e23',
      statusBar: '#dae8c0',
      windowBorder: '#8b9969',
    },
  },
  'midnight-blue': {
    name: 'Midnight Blue',
    colors: {
      background: '#2c3e50',
      titleBar: 'linear-gradient(to bottom, #1a252f, #0d1419)',
      titleBarText: '#ecf0f1',
      menuBar: '#34495e',
      toolbar: '#34495e',
      panel: '#2c3e50',
      panelBorder: '#1a252f',
      button: '#34495e',
      buttonHover: '#4a5f7e',
      buttonActive: '#1a252f',
      input: '#34495e',
      inputBorder: '#4a5f7e',
      text: '#ecf0f1',
      textSecondary: '#bdc3c7',
      accent: '#3498db',
      statusBar: '#34495e',
      windowBorder: '#1a252f',
    },
  },
  'black': {
    name: 'Black',
    colors: {
      background: '#000000',
      titleBar: 'linear-gradient(to bottom, #1a1a1a, #000000)',
      titleBarText: '#ffffff',
      menuBar: '#0f0f0f',
      toolbar: '#0f0f0f',
      panel: '#111111',
      panelBorder: '#333333',
      button: '#1a1a1a',
      buttonHover: '#2a2a2a',
      buttonActive: '#0a0a0a',
      input: '#1a1a1a',
      inputBorder: '#333333',
      text: '#ffffff',
      textSecondary: '#cccccc',
      accent: '#ffffff',
      statusBar: '#0f0f0f',
      windowBorder: '#333333',
    },
  },
};

export function applyTheme(themeName: string) {
  const theme = themes[themeName] || themes['classic-grey'];
  const root = document.documentElement;

  // Map theme colors to existing CSS variables
  root.style.setProperty('--xp-face', theme.colors.background);
  root.style.setProperty('--xp-white', theme.colors.panel);
  root.style.setProperty('--xp-black', theme.colors.text);
  root.style.setProperty('--xp-gray', theme.colors.button);
  root.style.setProperty('--xp-dark-shadow', theme.colors.panelBorder);
  root.style.setProperty('--xp-light', theme.colors.toolbar);
  root.style.setProperty('--xp-hilight', theme.colors.panel);
  root.style.setProperty('--xp-shadow', theme.colors.windowBorder);

  // Set title bar gradient and text
  root.style.setProperty('--title-bar-bg', theme.colors.titleBar);
  root.style.setProperty('--title-bar-text', theme.colors.titleBarText);

  // Update html and body background directly for immediate effect
  document.documentElement.style.background = theme.colors.background;
  document.body.style.background = theme.colors.background;
  document.body.style.color = theme.colors.text;

  // Update all title bars
  const titleBars = document.querySelectorAll('.xp-title-bar');
  titleBars.forEach((bar) => {
    (bar as HTMLElement).style.background = theme.colors.titleBar;
    (bar as HTMLElement).style.color = theme.colors.titleBarText;
  });

  // Update map tiles for dark themes
  const isDarkTheme = themeName === 'dark-mode' || themeName === 'midnight-blue' || themeName === 'black';
  const tileLayers = document.querySelectorAll('.leaflet-tile-pane');
  tileLayers.forEach((layer) => {
    if (isDarkTheme) {
      (layer as HTMLElement).style.filter = 'invert(1) hue-rotate(180deg) brightness(0.9)';
    } else {
      (layer as HTMLElement).style.filter = 'none';
    }
  });

  // Update map container background
  const mapContainers = document.querySelectorAll('.leaflet-container');
  mapContainers.forEach((container) => {
    (container as HTMLElement).style.background = theme.colors.panel;
  });

  // Update status bar
  const statusBars = document.querySelectorAll('.xp-status-bar');
  statusBars.forEach((bar) => {
    (bar as HTMLElement).style.background = theme.colors.statusBar;
    (bar as HTMLElement).style.color = theme.colors.text;
  });

  // Update menu bar
  const menuBars = document.querySelectorAll('.xp-menu-bar');
  menuBars.forEach((bar) => {
    (bar as HTMLElement).style.background = theme.colors.menuBar;
    (bar as HTMLElement).style.color = theme.colors.text;
  });
}
