/**
 * TARGET BUSINESS CRITERIA
 * Only small, owner-operated businesses that would buy a $40-$200/month AI tool
 */

// Target business types (INCLUDE)
const TARGET_TYPES = [
  // Food & Beverage
  'restaurant', 'cafe', 'coffee', 'bakery', 'bar', 'food truck', 'catering',

  // Retail (small, local)
  'florist', 'print shop', 'sign shop', 'boutique', 'gift shop', 'pet store',
  'hardware store', 'bookstore', 'jewelry', 'salon', 'barber', 'spa',

  // Trades & Home Services
  'contractor', 'electrician', 'plumber', 'hvac', 'landscaper', 'painter',
  'roofer', 'carpenter', 'handyman', 'cleaning', 'moving', 'pest control',

  // Health & Wellness
  'dentist', 'chiropractor', 'physical therapy', 'gym', 'yoga', 'pilates',
  'massage', 'acupuncture', 'wellness',

  // Professional Services
  'real estate', 'insurance', 'accountant', 'lawyer', 'marketing', 'photographer',
  'videographer', 'graphic design', 'web design', 'consulting',

  // Automotive
  'auto repair', 'car wash', 'detailing', 'tire shop', 'oil change',

  // Other Local Services
  'daycare', 'tutoring', 'music lessons', 'pet grooming', 'dry cleaning',
  'locksmith', 'storage', 'repair shop'
];

// Exclude business types (EXCLUDE)
const EXCLUDE_TYPES = [
  // Enterprise/Corporate
  'enterprise', 'corporation', 'corporate', 'headquarters', 'hq',

  // Tech/SaaS
  'software', 'saas', 'tech startup', 'app development', 'cloud',

  // Government/Public
  'government', 'city hall', 'dmv', 'post office', 'library', 'museum',
  'school', 'university', 'college', 'hospital', 'clinic',

  // Large Retail
  'department store', 'big box', 'shopping mall', 'outlet',

  // Financial Institutions
  'bank', 'credit union', 'atm', 'stock', 'investment firm'
];

// Chain/Franchise business names to exclude
const CHAIN_NAMES = [
  // Food chains
  'starbucks', 'mcdonalds', 'mcdonald\'s', 'burger king', 'wendy\'s', 'wendys',
  'subway', 'dunkin', 'dunkin donuts', 'taco bell', 'kfc', 'popeyes',
  'chipotle', 'panera', 'panda express', 'five guys', 'in-n-out',
  'chick-fil-a', 'sonic', 'arby\'s', 'arbys', 'dominos', 'pizza hut',
  'papa john\'s', 'little caesars', 'jimmy john\'s', 'jersey mike\'s',

  // Retail chains
  'walmart', 'target', 'costco', 'kroger', 'safeway', 'albertsons',
  'cvs', 'walgreens', 'rite aid', '7-eleven', 'circle k', 'shell',
  'bp', 'chevron', 'exxon', 'mobil', 'marathon',

  // Hair/Beauty chains
  'supercuts', 'great clips', 'sport clips', 'sports clips', 'fantastic sams',
  'hair cuttery', 'regis', 'smartstyle', 'mastercuts',

  // Fitness chains
  'planet fitness', '24 hour fitness', 'la fitness', 'anytime fitness',
  'gold\'s gym', 'golds gym', 'orangetheory', 'crunch fitness',

  // Auto chains
  'jiffy lube', 'midas', 'meineke', 'pep boys', 'firestone',
  'goodyear', 'valvoline', 'maaco', 'carmax', 'autozone',

  // Other service chains
  'h&r block', 'fedex', 'ups store', 'mailboxes etc', 'kinko\'s',
  'office depot', 'staples', 'best buy', 'home depot', 'lowe\'s', 'lowes'
];

// Exclude keywords in business names
const EXCLUDE_NAME_KEYWORDS = [
  'inc.', 'corporation', 'corp.', 'llc', 'ltd',
  'international', 'global', 'worldwide', 'national',
  'franchise', 'chain', 'holdings', 'group',
  '& associates', 'partners', 'network'
];

/**
 * Checks if a business type matches our target criteria
 */
export function isTargetBusiness(businessType: string, businessName?: string): boolean {
  const typeLower = businessType.toLowerCase();
  const nameLower = businessName?.toLowerCase() || '';

  // PRIORITY CHECK: Filter out chain/franchise businesses by name
  for (const chainName of CHAIN_NAMES) {
    if (nameLower.includes(chainName)) {
      return false; // Definitely a chain - exclude immediately
    }
  }

  // Check type exclusions
  for (const excludeType of EXCLUDE_TYPES) {
    if (typeLower.includes(excludeType)) {
      return false;
    }
  }

  // Check name exclusions (corporate keywords)
  for (const keyword of EXCLUDE_NAME_KEYWORDS) {
    if (nameLower.includes(keyword.toLowerCase())) {
      // Allow if it's clearly a small business despite having LLC, etc.
      if (!nameLower.includes('family') && !nameLower.includes('local')) {
        return false;
      }
    }
  }

  // Check if it matches target types
  for (const targetType of TARGET_TYPES) {
    if (typeLower.includes(targetType)) {
      return true;
    }
  }

  // If unknown type, default to include (cautiously optimistic)
  if (typeLower === 'unknown' || typeLower === '') {
    return true;
  }

  return false;
}

/**
 * Calculates how well a business matches our ideal customer profile
 */
export function calculateTargetScore(
  businessType: string,
  businessName: string,
  hasWebsite: boolean,
  hasPhone: boolean
): number {
  let score = 0;

  // Base score: Is it a target business type?
  if (isTargetBusiness(businessType, businessName)) {
    score += 50;
  } else {
    return 0; // Not a target business at all
  }

  // Bonus: Has phone number (critical for cold calling)
  if (hasPhone) {
    score += 30;
  }

  // Bonus: Has website (shows they invest in their business)
  if (hasWebsite) {
    score += 10;
  }

  // Bonus: Priority business types (most likely to buy)
  const priorityTypes = [
    'restaurant', 'dentist', 'real estate', 'contractor', 'salon',
    'auto repair', 'lawyer', 'accountant', 'plumber', 'electrician'
  ];

  const typeLower = businessType.toLowerCase();
  if (priorityTypes.some(type => typeLower.includes(type))) {
    score += 10;
  }

  return Math.min(100, score);
}

/**
 * Filters a list of businesses to only include targets
 */
export function filterTargetBusinesses<T extends { business_type: string; business_name: string }>(
  businesses: T[]
): T[] {
  return businesses.filter(business =>
    isTargetBusiness(business.business_type, business.business_name)
  );
}
