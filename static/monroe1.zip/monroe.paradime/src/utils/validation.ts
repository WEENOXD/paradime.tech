import { parsePhoneNumber, isValidPhoneNumber } from 'libphonenumber-js';
import type { Bounds } from '../types/apiTypes';

/**
 * Validates if a phone number is valid US format
 */
export function isValidPhone(phone: string | undefined): boolean {
  if (!phone) return false;

  try {
    return isValidPhoneNumber(phone, 'US');
  } catch {
    // Fallback to simple regex if parsing fails
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length === 10 || (cleaned.length === 11 && cleaned[0] === '1');
  }
}

/**
 * Formats phone number to (XXX) XXX-XXXX format
 */
export function formatPhone(phone: string | undefined): string {
  if (!phone) return '';

  try {
    const phoneNumber = parsePhoneNumber(phone, 'US');
    if (phoneNumber) {
      return phoneNumber.formatNational(); // Returns (XXX) XXX-XXXX
    }
  } catch {
    // Continue to fallback
  }

  // Fallback formatting
  const cleaned = phone.replace(/\D/g, '');

  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }

  if (cleaned.length === 11 && cleaned[0] === '1') {
    return `(${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }

  return phone; // Return original if can't parse
}

/**
 * Normalize phone number to digits only for comparison
 */
export function normalizePhone(phone: string | undefined): string {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
}

/**
 * Validates if coordinates are valid lat/lng values
 */
export function isValidCoordinate(lat: number | undefined, lng: number | undefined): boolean {
  if (lat === undefined || lng === undefined) return false;
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}

/**
 * Checks if a coordinate is within the specified bounds
 */
export function isWithinBounds(lat: number, lng: number, bounds: Bounds): boolean {
  return (
    lat >= bounds.south &&
    lat <= bounds.north &&
    lng >= bounds.west &&
    lng <= bounds.east
  );
}

/**
 * Validates if a URL is properly formatted
 */
export function isValidUrl(url: string | undefined): boolean {
  if (!url) return false;

  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Validates a ZIP code (US format: 12345 or 12345-6789)
 */
export function isValidZip(zip: string | undefined): boolean {
  if (!zip) return false;
  return /^\d{5}(-\d{4})?$/.test(zip);
}

/**
 * Validates a US state code (2-letter)
 */
export function isValidStateCode(state: string | undefined): boolean {
  if (!state || state.length !== 2) return false;

  const validStates = [
    'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
    'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
    'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
    'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
    'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY',
    'DC' // Washington DC
  ];

  return validStates.includes(state.toUpperCase());
}

/**
 * Normalizes a business name for comparison
 * Removes special chars, common suffixes like LLC, Inc, etc.
 */
export function normalizeBusinessName(name: string | undefined): string {
  if (!name) return '';

  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '') // Remove special chars
    .replace(/\b(llc|inc|corp|corporation|ltd|limited|co|company)\b/g, '') // Remove business suffixes
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim();
}

/**
 * Calculates the quality score (0-100) for a lead based on completeness
 */
export function calculateQualityScore(lead: {
  business_name?: string;
  phone_number?: string;
  lat?: number;
  lng?: number;
  city?: string;
  state?: string;
  website_url?: string;
  address_line1?: string;
  zip?: string;
  business_type?: string;
  data_source?: string;
}): number {
  let score = 0;

  // Required fields (50 points total)
  if (lead.business_name && lead.business_name.length > 2) score += 10;
  if (lead.phone_number && isValidPhone(lead.phone_number)) score += 20;
  if (isValidCoordinate(lead.lat, lead.lng)) score += 10;
  if (lead.city && lead.state) score += 10;

  // High-value optional fields (30 points)
  if (lead.website_url && isValidUrl(lead.website_url)) score += 15;
  if (lead.address_line1) score += 10;
  if (lead.zip && isValidZip(lead.zip)) score += 5;

  // Business type quality (10 points)
  if (lead.business_type && !lead.business_type.includes('Unknown')) score += 10;

  // Source bonus/penalty (10 points)
  switch (lead.data_source) {
    case 'google_places':
      score += 10;
      break;
    case 'yelp':
      score += 8;
      break;
    case 'overpass':
      score += 3;
      break;
    default:
      score += 0;
  }

  return Math.min(100, Math.max(0, score));
}

/**
 * Sanitizes a string to prevent XSS/injection
 */
export function sanitizeString(input: string | undefined): string {
  if (!input) return '';
  return input
    .replace(/[<>\"']/g, '') // Remove potentially dangerous chars
    .trim();
}
