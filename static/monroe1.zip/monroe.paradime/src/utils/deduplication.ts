import { compareTwoStrings } from 'string-similarity';
import type { Lead } from '../types/lead';
import type { NormalizedBusiness } from '../types/apiTypes';
import { normalizePhone, normalizeBusinessName } from './validation';

/**
 * Calculates the distance between two coordinates using the Haversine formula
 * Returns distance in kilometers
 */
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates string similarity between two business names (0-1)
 * Uses normalized names for better matching
 */
export function calculateNameSimilarity(name1: string, name2: string): number {
  const normalized1 = normalizeBusinessName(name1);
  const normalized2 = normalizeBusinessName(name2);

  if (normalized1 === normalized2) return 1.0;
  if (!normalized1 || !normalized2) return 0;

  // Use string-similarity library for Dice coefficient
  return compareTwoStrings(normalized1, normalized2);
}

/**
 * Checks if two businesses are duplicates based on phone, name, and location
 */
export function isDuplicate(
  lead1: Lead | NormalizedBusiness,
  lead2: Lead | NormalizedBusiness,
  options: {
    phoneMatchThreshold?: number; // exact match
    nameMatchThreshold?: number; // 0.8 default
    distanceThresholdKm?: number; // 0.05 km (50 meters) default
  } = {}
): boolean {
  const {
    nameMatchThreshold = 0.8,
    distanceThresholdKm = 0.05, // 50 meters
  } = options;

  // Level 1: Phone number exact match
  if (lead1.phone_number && lead2.phone_number) {
    const phone1 = normalizePhone(lead1.phone_number);
    const phone2 = normalizePhone(lead2.phone_number);

    if (phone1 && phone2 && phone1 === phone2) {
      return true; // Exact phone match = duplicate
    }
  }

  // Level 2: Name similarity + geographic proximity
  const nameSimilarity = calculateNameSimilarity(
    lead1.business_name,
    lead2.business_name
  );

  if (nameSimilarity > nameMatchThreshold) {
    const distance = calculateDistance(lead1.lat, lead1.lng, lead2.lat, lead2.lng);

    if (distance < distanceThresholdKm) {
      return true; // Similar name + same location = duplicate
    }
  }

  return false;
}

/**
 * Removes duplicates from an array of normalized businesses
 * Compares against existing leads in the database as well
 */
export async function deduplicateLeads(
  newLeads: NormalizedBusiness[],
  existingLeads: Lead[]
): Promise<NormalizedBusiness[]> {
  const unique: NormalizedBusiness[] = [];
  const seenPhones = new Set<string>();
  const seenNameLocations = new Set<string>();

  // First, build a set of existing phone numbers and name-location combos
  for (const existing of existingLeads) {
    if (existing.phone_number) {
      seenPhones.add(normalizePhone(existing.phone_number));
    }

    const nameKey = normalizeBusinessName(existing.business_name);
    const locationKey = `${existing.lat?.toFixed(4)},${existing.lng?.toFixed(4)}`;
    seenNameLocations.add(`${nameKey}:${locationKey}`);
  }

  // Process new leads
  for (const lead of newLeads) {
    let isDupe = false;

    // Check 1: Phone number in existing database
    if (lead.phone_number) {
      const normalizedPhone = normalizePhone(lead.phone_number);
      if (normalizedPhone && seenPhones.has(normalizedPhone)) {
        continue; // Skip - duplicate phone
      }
    }

    // Check 2: Compare against existing leads (deep check)
    for (const existing of existingLeads) {
      if (isDuplicate(lead, existing)) {
        isDupe = true;
        break;
      }
    }

    if (isDupe) continue;

    // Check 3: Compare against already-processed new leads
    for (const uniqueLead of unique) {
      if (isDuplicate(lead, uniqueLead)) {
        isDupe = true;
        break;
      }
    }

    if (isDupe) continue;

    // Not a duplicate - add to unique set
    unique.push(lead);

    // Track this lead to prevent future duplicates
    if (lead.phone_number) {
      seenPhones.add(normalizePhone(lead.phone_number));
    }

    const nameKey = normalizeBusinessName(lead.business_name);
    const locationKey = `${lead.lat?.toFixed(4)},${lead.lng?.toFixed(4)}`;
    seenNameLocations.add(`${nameKey}:${locationKey}`);
  }

  return unique;
}

/**
 * Merges duplicate leads by keeping the one with the highest quality score
 */
export function mergeDuplicates(leads: NormalizedBusiness[]): NormalizedBusiness[] {
  const merged: NormalizedBusiness[] = [];

  for (const lead of leads) {
    // Find if there's already a similar lead in merged
    const existingIndex = merged.findIndex((m) => isDuplicate(lead, m));

    if (existingIndex >= 0) {
      // Keep the one with higher quality score
      const existing = merged[existingIndex];
      if (lead.data_quality_score > existing.data_quality_score) {
        merged[existingIndex] = lead; // Replace with better quality
      }
      // Otherwise keep existing
    } else {
      merged.push(lead); // Not a duplicate
    }
  }

  return merged;
}

/**
 * Groups leads by proximity to identify potential duplicates
 * Useful for manual review
 */
export function groupByProximity(
  leads: (Lead | NormalizedBusiness)[],
  radiusKm: number = 0.1 // 100 meters
): Array<(Lead | NormalizedBusiness)[]> {
  const groups: Array<(Lead | NormalizedBusiness)[]> = [];
  const processed = new Set<string>();

  for (const lead of leads) {
    const leadId = 'id' in lead ? lead.id : lead.external_id;
    if (processed.has(leadId)) continue;

    const group: (Lead | NormalizedBusiness)[] = [lead];
    processed.add(leadId);

    // Find all leads within radius
    for (const otherLead of leads) {
      const otherId = 'id' in otherLead ? otherLead.id : otherLead.external_id;
      if (processed.has(otherId)) continue;

      const distance = calculateDistance(
        lead.lat,
        lead.lng,
        otherLead.lat,
        otherLead.lng
      );

      if (distance <= radiusKm) {
        group.push(otherLead);
        processed.add(otherId);
      }
    }

    if (group.length > 0) {
      groups.push(group);
    }
  }

  return groups;
}
