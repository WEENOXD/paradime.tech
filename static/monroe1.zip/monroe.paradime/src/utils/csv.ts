import Papa from 'papaparse';
import { v4 as uuidv4 } from 'uuid';
import type { Lead, LeadStatus } from '../types/lead';

export const exportToCSV = (leads: Lead[], filename: string = 'leads.csv') => {
  const csv = Papa.unparse(leads);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const downloadSampleCSV = () => {
  const sampleData: Partial<Lead>[] = [
    {
      business_name: 'Sample Business Inc',
      business_type: 'Technology',
      owner_or_manager_name: 'John Doe',
      phone_number: '(555) 123-4567',
      website_url: 'https://example.com',
      address_line1: '123 Main St',
      city: 'San Francisco',
      state: 'CA',
      zip: '94102',
      lat: 37.7749,
      lng: -122.4194,
      notes: '',
      status: 'NotContacted',
      already_dialed: false,
    },
  ];

  const csv = Papa.unparse(sampleData);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', 'sample_leads.csv');
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

interface ImportResult {
  success: boolean;
  leads?: Lead[];
  errors?: string[];
}

export const importFromCSV = (file: File): Promise<ImportResult> => {
  return new Promise((resolve) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const errors: string[] = [];
        const leads: Lead[] = [];
        const now = new Date().toISOString();

        results.data.forEach((row: any, index: number) => {
          const rowNum = index + 2; // +2 for header + 1-based indexing

          // Validate required fields
          if (!row.business_name || !row.business_name.trim()) {
            errors.push(`Row ${rowNum}: Missing business_name`);
            return;
          }
          if (!row.phone_number || !row.phone_number.trim()) {
            errors.push(`Row ${rowNum}: Missing phone_number`);
            return;
          }
          if (!row.city || !row.city.trim()) {
            errors.push(`Row ${rowNum}: Missing city`);
            return;
          }
          if (!row.state || !row.state.trim()) {
            errors.push(`Row ${rowNum}: Missing state`);
            return;
          }

          // Validate lat/lng
          const lat = parseFloat(row.lat);
          const lng = parseFloat(row.lng);
          if (isNaN(lat) || isNaN(lng)) {
            errors.push(`Row ${rowNum}: Invalid or missing lat/lng coordinates`);
            return;
          }

          // Validate status
          const validStatuses: LeadStatus[] = [
            'NotContacted',
            'Called',
            'LeftVM',
            'Interested',
            'FollowUp',
            'Closed',
            'NotAFit',
          ];
          const status = (row.status || 'NotContacted') as LeadStatus;
          if (!validStatuses.includes(status)) {
            errors.push(
              `Row ${rowNum}: Invalid status "${row.status}". Must be one of: ${validStatuses.join(', ')}`
            );
            return;
          }

          // Create lead
          const lead: Lead = {
            id: row.id || uuidv4(),
            business_name: row.business_name.trim(),
            business_type: row.business_type?.trim() || 'Other',
            owner_or_manager_name: row.owner_or_manager_name?.trim() || undefined,
            phone_number: row.phone_number.trim(),
            website_url: row.website_url?.trim() || undefined,
            address_line1: row.address_line1?.trim() || undefined,
            city: row.city.trim(),
            state: row.state.trim(),
            zip: row.zip?.trim() || undefined,
            lat,
            lng,
            notes: row.notes || '',
            status,
            already_dialed: row.already_dialed === 'true' || row.already_dialed === true || false,
            last_contacted_at: row.last_contacted_at || null,
            next_follow_up_at: row.next_follow_up_at || null,
            created_at: row.created_at || now,
            updated_at: row.updated_at || now,
          };

          leads.push(lead);
        });

        if (errors.length > 0) {
          resolve({ success: false, errors });
        } else if (leads.length === 0) {
          resolve({ success: false, errors: ['No valid leads found in CSV file'] });
        } else {
          resolve({ success: true, leads });
        }
      },
      error: (error) => {
        resolve({ success: false, errors: [`Failed to parse CSV: ${error.message}`] });
      },
    });
  });
};
