import React, { useState, useEffect } from 'react';
import type { Lead, LeadStatus } from '../types/lead';
import { Button } from './ui/Button';
import { db } from '../db/database';
import OpenAI from 'openai';

interface LeadDetailProps {
  lead: Lead | null;
  onClose: () => void;
  onUpdate: () => void;
}

const STATUS_OPTIONS: LeadStatus[] = [
  'NotContacted',
  'Called',
  'LeftVM',
  'Interested',
  'FollowUp',
  'Closed',
  'NotAFit',
];

export const LeadDetail: React.FC<LeadDetailProps> = ({ lead, onClose, onUpdate }) => {
  const [notes, setNotes] = useState('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [script, setScript] = useState('');
  const [scriptError, setScriptError] = useState('');

  useEffect(() => {
    if (lead) {
      setNotes(lead.notes);
      setScript('');
      setScriptError('');
    }
  }, [lead]);

  useEffect(() => {
    if (!lead) return;

    const timeoutId = setTimeout(async () => {
      if (notes !== lead.notes) {
        await db.leads.update(lead.id, {
          notes,
          updated_at: new Date().toISOString(),
        });
        onUpdate();
      }
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [notes, lead, onUpdate]);

  if (!lead) {
    return null;
  }

  const updateStatus = async (status: LeadStatus) => {
    await db.leads.update(lead.id, {
      status,
      last_contacted_at: ['Called', 'LeftVM', 'Interested'].includes(status)
        ? new Date().toISOString()
        : lead.last_contacted_at,
      updated_at: new Date().toISOString(),
    });
    onUpdate();
  };

  const setFollowUp = async (days: number) => {
    const followUpDate = new Date();
    followUpDate.setDate(followUpDate.getDate() + days);

    await db.leads.update(lead.id, {
      next_follow_up_at: followUpDate.toISOString(),
      status: 'FollowUp',
      updated_at: new Date().toISOString(),
    });
    onUpdate();
  };

  const generateScript = async () => {
    setIsGeneratingScript(true);
    setScriptError('');
    setScript('');

    try {
      const settings = await db.settings.get('default');

      if (!settings?.openai_api_key) {
        setScriptError('Please add your OpenAI API key in Settings first.');
        setIsGeneratingScript(false);
        return;
      }

      const openai = new OpenAI({
        apiKey: settings.openai_api_key,
        dangerouslyAllowBrowser: true,
      });

      const prompt = `Generate a professional cold call script for the following business:

Business Name: ${lead.business_name}
Type: ${lead.business_type}
Location: ${lead.city}, ${lead.state}
${lead.website_url ? `Website: ${lead.website_url}` : ''}
${lead.owner_or_manager_name ? `Contact: ${lead.owner_or_manager_name}` : ''}

Tone: ${settings.script_tone}

Please create a script with:
1. A 20-30 second opener
2. 3 discovery questions
3. 2 tailored value points
4. Objection handling for "not interested" and "send an email"
5. A close asking for a next step (5-min call or permission to send info)

Format the script clearly with headers and be conversational.`;

      const completion = await openai.chat.completions.create({
        model: settings.openai_model || 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are a sales script writing expert who creates effective, conversational cold call scripts.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 1000,
      });

      const generatedScript = completion.choices[0]?.message?.content || 'No script generated.';
      setScript(generatedScript);
    } catch (error: any) {
      setScriptError(error.message || 'Failed to generate script. Check your API key and try again.');
    } finally {
      setIsGeneratingScript(false);
    }
  };

  return (
    <div className="fixed right-0 top-0 bottom-0 w-[500px] webcore-panel border-l-2 border-white border-opacity-30 flex flex-col z-40 overflow-hidden">
      <div className="webcore-window-header">
        <span>Lead Details</span>
        <button
          onClick={onClose}
          className="text-2xl leading-none hover:opacity-70 transition-opacity"
          aria-label="Close"
        >
          ×
        </button>
      </div>

      <div className="flex-1 overflow-y-auto webcore-scrollbar p-6 space-y-4">
        <div>
          <h2 className="text-2xl font-bold mb-1">{lead.business_name}</h2>
          <p className="text-gray-400 text-sm">{lead.business_type}</p>
        </div>

        <div className="webcore-divider" />

        <div className="space-y-3 text-sm">
          {lead.owner_or_manager_name && (
            <div>
              <span className="text-gray-400">Contact:</span>{' '}
              <span className="font-medium">{lead.owner_or_manager_name}</span>
            </div>
          )}

          <div>
            <span className="text-gray-400">Phone:</span>{' '}
            <a
              href={`tel:${lead.phone_number}`}
              className="font-medium hover:text-blue-400 transition-colors"
            >
              {lead.phone_number}
            </a>
            <button
              onClick={() => navigator.clipboard.writeText(lead.phone_number)}
              className="ml-2 text-xs text-blue-400 hover:text-blue-300"
            >
              Copy
            </button>
          </div>

          {lead.website_url && (
            <div>
              <span className="text-gray-400">Website:</span>{' '}
              <a
                href={lead.website_url}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium hover:text-blue-400 transition-colors"
              >
                {lead.website_url}
              </a>
            </div>
          )}

          <div>
            <span className="text-gray-400">Address:</span>{' '}
            <span className="font-medium">
              {lead.address_line1 && `${lead.address_line1}, `}
              {lead.city}, {lead.state} {lead.zip}
            </span>
          </div>
        </div>

        <div className="webcore-divider" />

        <div>
          <label className="block text-sm font-semibold mb-2">Status</label>
          <div className="flex flex-wrap gap-2">
            {STATUS_OPTIONS.map((status) => (
              <button
                key={status}
                onClick={() => updateStatus(status)}
                className={`status-chip status-${status} cursor-pointer hover:opacity-80 transition-opacity ${
                  lead.status === status ? 'ring-2 ring-white ring-opacity-50' : ''
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold mb-2">Quick Actions</label>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setFollowUp(3)} className="text-xs">
              Follow up in 3 days
            </Button>
            <Button variant="secondary" onClick={() => setFollowUp(7)} className="text-xs">
              Follow up in 7 days
            </Button>
          </div>
        </div>

        <div className="webcore-divider" />

        <div>
          <label htmlFor="notes" className="block text-sm font-semibold mb-2">
            Notes (autosaves)
          </label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="webcore-input w-full h-32 resize-none font-mono text-sm"
            placeholder="Add your notes here..."
          />
        </div>

        <div className="webcore-divider" />

        <div>
          <Button
            variant="success"
            onClick={generateScript}
            disabled={isGeneratingScript}
            className="w-full"
          >
            {isGeneratingScript ? 'Generating Script...' : '✨ Generate Call Script'}
          </Button>

          {scriptError && (
            <div className="mt-3 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded text-sm">
              {scriptError}
            </div>
          )}

          {script && (
            <div className="mt-3 webcore-panel p-4 bg-black bg-opacity-40 max-h-96 overflow-y-auto webcore-scrollbar">
              <div className="text-xs font-mono text-green-400 mb-2">
                ━━━ GENERATED CALL SCRIPT ━━━
              </div>
              <pre className="whitespace-pre-wrap text-sm font-sans text-gray-200">{script}</pre>
            </div>
          )}
        </div>

        {lead.last_contacted_at && (
          <div className="text-xs text-gray-500">
            Last contacted: {new Date(lead.last_contacted_at).toLocaleString()}
          </div>
        )}
        {lead.next_follow_up_at && (
          <div className="text-xs text-yellow-400">
            Follow up: {new Date(lead.next_follow_up_at).toLocaleString()}
          </div>
        )}
      </div>
    </div>
  );
};
