import React from 'react';
import type { Lead } from '../types/lead';

interface LeadListProps {
  leads: Lead[];
  selectedLead: Lead | null;
  onSelectLead: (lead: Lead) => void;
}

export const LeadList: React.FC<LeadListProps> = ({ leads, selectedLead, onSelectLead }) => {
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-white border-opacity-20">
        <h2 className="font-bold text-lg">Leads ({leads.length})</h2>
      </div>
      <div className="flex-1 overflow-y-auto webcore-scrollbar">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-black bg-opacity-30 backdrop-blur-sm">
            <tr className="text-left border-b border-white border-opacity-20">
              <th className="p-3 font-semibold">Name</th>
              <th className="p-3 font-semibold">Type</th>
              <th className="p-3 font-semibold">Location</th>
              <th className="p-3 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((lead) => (
              <tr
                key={lead.id}
                onClick={() => onSelectLead(lead)}
                className={`cursor-pointer border-b border-white border-opacity-10 hover:bg-white hover:bg-opacity-10 transition-colors ${
                  selectedLead?.id === lead.id ? 'bg-blue-500 bg-opacity-20' : ''
                }`}
              >
                <td className="p-3 font-medium">{lead.business_name}</td>
                <td className="p-3 text-gray-300">{lead.business_type}</td>
                <td className="p-3 text-gray-300">
                  {lead.city}, {lead.state}
                </td>
                <td className="p-3">
                  <span className={`status-chip status-${lead.status}`}>
                    {lead.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {leads.length === 0 && (
          <div className="p-8 text-center text-gray-400">
            No leads found. Try adjusting your filters or import some leads.
          </div>
        )}
      </div>
    </div>
  );
};
