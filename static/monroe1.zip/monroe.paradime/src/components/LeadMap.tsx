import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import type { Lead } from '../types/lead';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in React Leaflet
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow,
});

interface LeadMapProps {
  leads: Lead[];
  selectedLead: Lead | null;
  onSelectLead: (lead: Lead) => void;
}

// Component to handle map centering
const MapController: React.FC<{ center: [number, number]; zoom: number }> = ({ center, zoom }) => {
  const map = useMap();

  useEffect(() => {
    map.setView(center, zoom);
  }, [map, center, zoom]);

  return null;
};

export const LeadMap: React.FC<LeadMapProps> = ({ leads, selectedLead, onSelectLead }) => {
  const center: [number, number] = selectedLead
    ? [selectedLead.lat, selectedLead.lng]
    : [39.8283, -98.5795]; // Center of USA

  const zoom = selectedLead ? 13 : 4;

  return (
    <div className="h-full w-full">
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        className="webcore-panel"
      >
        <MapController center={center} zoom={zoom} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {leads.map((lead) => (
          <Marker
            key={lead.id}
            position={[lead.lat, lead.lng]}
            eventHandlers={{
              click: () => onSelectLead(lead),
            }}
          >
            <Popup>
              <div className="text-sm">
                <strong>{lead.business_name}</strong>
                <br />
                {lead.business_type}
                <br />
                {lead.city}, {lead.state}
                <br />
                <span className={`status-chip status-${lead.status} mt-1`}>
                  {lead.status}
                </span>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};
