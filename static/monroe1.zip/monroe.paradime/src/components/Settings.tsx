import React, { useState, useEffect } from 'react';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Select } from './ui/Select';
import { db } from '../db/database';
import type { Settings as SettingsType } from '../types/lead';

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<SettingsType>({
    id: 'default',
    openai_api_key: '',
    openai_model: 'gpt-4o-mini',
    script_tone: 'Professional',
    user_name: '',
    user_email: '',
  });
  const [isSaved, setIsSaved] = useState(false);
  const [balance, setBalance] = useState<string | null>(null);
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [balanceError, setBalanceError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadSettings();
    }
  }, [isOpen]);

  const loadSettings = async () => {
    const storedSettings = await db.settings.get('default');
    if (storedSettings) {
      setSettings(storedSettings);
    }
  };

  const handleSave = async () => {
    await db.settings.put(settings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setSettings({ ...settings, openai_api_key: text.trim() });
    } catch (err) {
      console.error('Failed to read clipboard:', err);
    }
  };

  const checkBalance = async () => {
    if (!settings.openai_api_key) {
      setBalanceError('Please enter an API key first');
      return;
    }

    setLoadingBalance(true);
    setBalanceError(null);
    setBalance(null);

    try {
      const response = await fetch('https://api.openai.com/v1/dashboard/billing/subscription', {
        headers: {
          'Authorization': `Bearer ${settings.openai_api_key}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch balance. Make sure your API key is valid.');
      }

      const data = await response.json();

      // Try to get usage information
      const usageResponse = await fetch('https://api.openai.com/v1/dashboard/billing/usage', {
        headers: {
          'Authorization': `Bearer ${settings.openai_api_key}`,
        },
      });

      if (usageResponse.ok) {
        const usageData = await usageResponse.json();
        setBalance(`$${((data.hard_limit_usd || 0) - (usageData.total_usage || 0) / 100).toFixed(2)}`);
      } else {
        // Fallback: just show the limit
        setBalance(`Limit: $${(data.hard_limit_usd || 0).toFixed(2)}`);
      }
    } catch (err) {
      setBalanceError(err instanceof Error ? err.message : 'Failed to check balance. Note: This feature may not work with all API key types.');
      console.error('Balance check error:', err);
    } finally {
      setLoadingBalance(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="⚙️ Settings">
      <div className="space-y-6">
        <div>
          <h3 className="font-bold text-lg mb-4">OpenAI Configuration</h3>

          <div className="space-y-4">
            <div>
              <label htmlFor="api-key" className="block text-sm font-semibold mb-2">
                OpenAI API Key
              </label>
              <div className="flex gap-2">
                <Input
                  id="api-key"
                  type="password"
                  value={settings.openai_api_key}
                  onChange={(e) => setSettings({ ...settings, openai_api_key: e.target.value })}
                  placeholder="sk-..."
                  className="flex-1"
                />
                <Button variant="secondary" onClick={handlePaste} className="px-4">
                  📋 Paste
                </Button>
                <Button
                  variant="secondary"
                  onClick={checkBalance}
                  disabled={loadingBalance}
                  className="px-4"
                >
                  {loadingBalance ? '...' : '💰 Check'}
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Your API key is stored locally and never sent anywhere except OpenAI.
              </p>
              {balance && (
                <p className="text-xs text-green-400 mt-1 font-semibold">
                  Balance: {balance}
                </p>
              )}
              {balanceError && (
                <p className="text-xs text-red-400 mt-1">
                  {balanceError}
                </p>
              )}
            </div>

            <div>
              <label htmlFor="model" className="block text-sm font-semibold mb-2">
                Model
              </label>
              <Select
                id="model"
                value={settings.openai_model}
                onChange={(e) => setSettings({ ...settings, openai_model: e.target.value })}
              >
                <option value="gpt-4o-mini">GPT-4o Mini (Recommended)</option>
                <option value="gpt-4o">GPT-4o</option>
                <option value="gpt-4-turbo">GPT-4 Turbo</option>
                <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
              </Select>
            </div>

            <div>
              <label htmlFor="tone" className="block text-sm font-semibold mb-2">
                Script Tone
              </label>
              <Select
                id="tone"
                value={settings.script_tone}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    script_tone: e.target.value as 'Friendly' | 'Professional' | 'Concise',
                  })
                }
              >
                <option value="Friendly">Friendly</option>
                <option value="Professional">Professional</option>
                <option value="Concise">Concise</option>
              </Select>
            </div>
          </div>
        </div>

        <div className="webcore-divider" />

        <div>
          <h3 className="font-bold text-lg mb-4">Your Information (Optional)</h3>

          <div className="space-y-4">
            <div>
              <label htmlFor="user-name" className="block text-sm font-semibold mb-2">
                Your Name
              </label>
              <Input
                id="user-name"
                type="text"
                value={settings.user_name || ''}
                onChange={(e) => setSettings({ ...settings, user_name: e.target.value })}
                placeholder="John Doe"
              />
            </div>

            <div>
              <label htmlFor="user-email" className="block text-sm font-semibold mb-2">
                Your Email
              </label>
              <Input
                id="user-email"
                type="email"
                value={settings.user_email || ''}
                onChange={(e) => setSettings({ ...settings, user_email: e.target.value })}
                placeholder="john@example.com"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <Button variant="primary" onClick={handleSave} className="flex-1">
            {isSaved ? '✓ Saved!' : 'Save Settings'}
          </Button>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </Modal>
  );
};
