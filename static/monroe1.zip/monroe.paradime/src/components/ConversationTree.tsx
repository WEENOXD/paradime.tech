import { useState } from 'react';
import type { ConversationTurn } from '../types/conversation';

interface ConversationTreeProps {
  turns: ConversationTurn[];
  isGenerating: boolean;
  onSelectResponse: (turnId: string, optionId: string) => void;
  onCustomResponse: (turnId: string, customText: string) => void;
}

export function ConversationTree({
  turns,
  isGenerating,
  onSelectResponse,
  onCustomResponse,
}: ConversationTreeProps) {
  const [customResponses, setCustomResponses] = useState<Record<string, string>>({});
  const [showCustomInput, setShowCustomInput] = useState<Record<string, boolean>>({});

  const handleCustomSubmit = (turnId: string) => {
    const customText = customResponses[turnId]?.trim();
    if (customText) {
      onCustomResponse(turnId, customText);
      setCustomResponses({ ...customResponses, [turnId]: '' });
      setShowCustomInput({ ...showCustomInput, [turnId]: false });
    }
  };

  return (
    <div className="xp-window" style={{ maxHeight: '600px', overflowY: 'auto' }}>
      <div className="xp-window-title">Interactive Sales Script</div>
      <div className="xp-window-content" style={{ padding: '12px' }}>
        {turns.length === 0 && (
          <div style={{ color: '#666', fontStyle: 'italic', padding: '20px', textAlign: 'center' }}>
            Click "Generate Script" to start the conversation flow
          </div>
        )}

        {turns.map((turn, index) => (
          <div key={turn.id} style={{ marginBottom: '20px' }}>
            {/* Sales Rep Message */}
            {turn.speaker === 'sales_rep' && (
              <div>
                <div
                  style={{
                    background: '#e3f2fd',
                    border: '2px solid #2196f3',
                    padding: '12px',
                    borderRadius: '8px',
                    marginBottom: '12px',
                  }}
                >
                  <div
                    style={{
                      fontWeight: 'bold',
                      color: '#1976d2',
                      marginBottom: '8px',
                      fontSize: '12px',
                    }}
                  >
                    💼 YOU (Sales Rep):
                  </div>
                  <div style={{ whiteSpace: 'pre-wrap', lineHeight: '1.5' }}>{turn.message}</div>
                </div>

                {/* Customer Response Options - only show if this is the last turn */}
                {index === turns.length - 1 &&
                  turn.customerResponseOptions &&
                  !turn.selectedResponseId &&
                  !turn.customResponse && (
                    <div style={{ marginLeft: '20px' }}>
                      <div
                        style={{
                          fontWeight: 'bold',
                          marginBottom: '8px',
                          fontSize: '12px',
                          color: '#666',
                        }}
                      >
                        👤 How might the customer respond?
                      </div>

                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {turn.customerResponseOptions.map((option) => (
                          <button
                            key={option.id}
                            className="xp-button"
                            onClick={() => onSelectResponse(turn.id, option.id)}
                            disabled={isGenerating}
                            style={{
                              textAlign: 'left',
                              padding: '10px',
                              background: '#fff',
                              border: '2px solid #999',
                              cursor: isGenerating ? 'wait' : 'pointer',
                            }}
                          >
                            <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
                              {option.label}
                            </div>
                            <div style={{ fontSize: '11px', color: '#555' }}>{option.text}</div>
                          </button>
                        ))}

                        {/* Custom Response Option */}
                        {!showCustomInput[turn.id] ? (
                          <button
                            className="xp-button"
                            onClick={() =>
                              setShowCustomInput({ ...showCustomInput, [turn.id]: true })
                            }
                            disabled={isGenerating}
                            style={{
                              padding: '10px',
                              background: '#f5f5f5',
                              fontStyle: 'italic',
                            }}
                          >
                            ✏️ Type custom response...
                          </button>
                        ) : (
                          <div
                            style={{
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '8px',
                              padding: '10px',
                              background: '#f5f5f5',
                              border: '2px solid #999',
                              borderRadius: '4px',
                            }}
                          >
                            <textarea
                              value={customResponses[turn.id] || ''}
                              onChange={(e) =>
                                setCustomResponses({
                                  ...customResponses,
                                  [turn.id]: e.target.value,
                                })
                              }
                              placeholder="What does the customer say?"
                              style={{
                                width: '100%',
                                minHeight: '60px',
                                padding: '8px',
                                border: '1px solid #999',
                                borderRadius: '4px',
                                fontFamily: 'inherit',
                                fontSize: '13px',
                              }}
                              disabled={isGenerating}
                            />
                            <div style={{ display: 'flex', gap: '8px' }}>
                              <button
                                className="xp-button"
                                onClick={() => handleCustomSubmit(turn.id)}
                                disabled={isGenerating || !customResponses[turn.id]?.trim()}
                                style={{ flex: 1 }}
                              >
                                Submit
                              </button>
                              <button
                                className="xp-button"
                                onClick={() =>
                                  setShowCustomInput({ ...showCustomInput, [turn.id]: false })
                                }
                                disabled={isGenerating}
                                style={{ flex: 1 }}
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
              </div>
            )}

            {/* Customer Response */}
            {turn.speaker === 'customer' && (
              <div style={{ marginLeft: '20px' }}>
                <div
                  style={{
                    background: '#f5f5f5',
                    border: '2px solid #999',
                    padding: '12px',
                    borderRadius: '8px',
                  }}
                >
                  <div
                    style={{
                      fontWeight: 'bold',
                      color: '#555',
                      marginBottom: '8px',
                      fontSize: '12px',
                    }}
                  >
                    👤 CUSTOMER:
                  </div>
                  <div style={{ whiteSpace: 'pre-wrap', lineHeight: '1.5' }}>{turn.message}</div>
                </div>
              </div>
            )}
          </div>
        ))}

        {isGenerating && (
          <div
            style={{
              textAlign: 'center',
              padding: '20px',
              color: '#666',
              fontStyle: 'italic',
            }}
          >
            🤖 Generating next response...
          </div>
        )}
      </div>
    </div>
  );
}
