/**
 * Interactive conversation flow for sales scripts
 * "Choose your own adventure" style script generation
 */

export interface CustomerResponseOption {
  id: string;
  label: string; // Short label: "Interested", "Price concern", "Not now"
  text: string; // Full customer response text
}

export interface ConversationTurn {
  id: string;
  speaker: 'sales_rep' | 'customer';
  message: string;

  // Only for sales_rep turns - what might the customer say next?
  customerResponseOptions?: CustomerResponseOption[];

  // Which option was selected (if any)
  selectedResponseId?: string;
  customResponse?: string; // If user typed custom response
}

export interface ConversationScript {
  id: string;
  leadId: string;
  leadName: string;
  turns: ConversationTurn[];
  createdAt: string;
  updatedAt: string;
}

/**
 * AI response format for generating next turn
 */
export interface AIScriptResponse {
  salesRepMessage: string;
  customerOptions: Array<{
    label: string;
    text: string;
  }>;
}
