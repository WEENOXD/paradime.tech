// API Response Types for Google Places, Yelp, and Overpass/OSM

export interface Bounds {
  north: number;
  south: number;
  east: number;
  west: number;
  center: {
    lat: number;
    lng: number;
  };
}

// ============================================================================
// GOOGLE PLACES API TYPES
// ============================================================================

export interface GooglePlaceResult {
  id: string;
  displayName?: {
    text: string;
    languageCode?: string;
  };
  name?: string;
  types?: string[];
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  formattedAddress?: string;
  addressComponents?: GoogleAddressComponent[];
  location?: {
    latitude: number;
    longitude: number;
  };
  websiteUri?: string;
  businessStatus?: string;
  rating?: number;
  userRatingCount?: number;
}

export interface GoogleAddressComponent {
  longText?: string;
  shortText?: string;
  types?: string[];
  languageCode?: string;
}

export interface GooglePlacesResponse {
  places?: GooglePlaceResult[];
  nextPageToken?: string;
}

// ============================================================================
// OVERPASS API / OPENSTREETMAP TYPES
// ============================================================================

export interface OverpassElement {
  type: 'node' | 'way' | 'relation';
  id: number;
  lat?: number;
  lon?: number;
  center?: {
    lat: number;
    lon: number;
  };
  tags: {
    name?: string;
    'name:en'?: string;
    amenity?: string;
    shop?: string;
    office?: string;
    craft?: string;
    phone?: string;
    'contact:phone'?: string;
    website?: string;
    'contact:website'?: string;
    'addr:housenumber'?: string;
    'addr:street'?: string;
    'addr:city'?: string;
    'addr:state'?: string;
    'addr:postcode'?: string;
    'addr:country'?: string;
    [key: string]: string | undefined;
  };
}

export interface OverpassResponse {
  version: number;
  generator: string;
  osm3s?: {
    timestamp_osm_base: string;
    copyright: string;
  };
  elements: OverpassElement[];
}

// ============================================================================
// NORMALIZED TYPES
// ============================================================================

export type DataSource = 'google_places' | 'overpass' | 'manual' | 'openai_legacy';

export interface NormalizedBusiness {
  external_id: string;
  data_source: DataSource;
  business_name: string;
  business_type: string;
  phone_number?: string;
  address_line1?: string;
  city?: string;
  state?: string;
  zip?: string;
  lat: number;
  lng: number;
  website_url?: string;
  raw_categories?: string[];
  notes?: string;
  data_quality_score: number;
}

export interface SearchResult {
  leads: NormalizedBusiness[];
  errors: Array<{ source: DataSource; error: Error }>;
  successfulSources: DataSource[];
  totalFound: number;
  totalAfterDedup: number;
}

export interface APIError {
  source: DataSource;
  message: string;
  code?: string | number;
  isQuotaError?: boolean;
  isRetryable?: boolean;
}
