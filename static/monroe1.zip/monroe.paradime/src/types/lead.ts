export type LeadStatus =
  | 'NotContacted'
  | 'Called'
  | 'LeftVM'
  | 'Interested'
  | 'FollowUp'
  | 'Closed'
  | 'NotAFit';

export type DataSource = 'google_places' | 'overpass' | 'manual' | 'openai_legacy';

export interface Lead {
  id: string;
  business_name: string;
  business_type: string;
  owner_or_manager_name?: string;
  phone_number: string;
  website_url?: string;
  address_line1?: string;
  city: string;
  state: string;
  zip?: string;
  lat: number;
  lng: number;
  notes: string;
  status: LeadStatus;
  already_dialed: boolean;
  last_contacted_at: string | null;
  next_follow_up_at: string | null;
  created_at: string;
  updated_at: string;

  // New fields for real data scraping
  data_source?: DataSource;
  data_quality_score?: number; // 0-100 based on completeness
  external_id?: string; // Google Place ID, Yelp ID, or OSM ID
  raw_categories?: string[]; // Original API categories for reference

  // Scraped website data
  scraped_emails?: string[];
  scraped_phones?: string[];
  facebook_url?: string;
  instagram_url?: string;
  twitter_url?: string;
  linkedin_url?: string;
  has_contact_form?: boolean;
  business_hours?: string;
}

export interface Settings {
  id: string;

  // Google Places API (Primary data source)
  google_places_api_key?: string;
  google_places_enabled?: boolean;

  // Overpass/OSM (Secondary - always available, no key needed)
  overpass_enabled?: boolean;

  // OpenAI (for sales scripts only, not lead generation)
  openai_api_key: string;
  openai_model: string;
  script_tone: 'Friendly' | 'Professional' | 'Concise' | 'Casual' | 'Formal';

  // User info
  user_name?: string;
  user_email?: string;

  // Search preferences
  max_results_per_search?: number; // default: 200
  min_data_quality_score?: number; // default: 60
  prefer_businesses_with_phone?: boolean; // default: true
  prefer_businesses_with_website?: boolean; // default: false

  // UI preferences
  theme?: string; // default: 'classic-grey'
}

export interface Filters {
  search: string;
  business_type: string;
  status: LeadStatus | '';
  state: string;
  has_website: boolean | null;
}
