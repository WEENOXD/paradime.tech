import { useState, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { MapContainer, TileLayer, FeatureGroup, useMap } from 'react-leaflet';
import { db } from './db/database';
import { initializeDatabase } from './db/seedData';
import type { Lead } from './types/lead';
import type { ConversationTurn, AIScriptResponse } from './types/conversation';
import { ConversationTree } from './components/ConversationTree';
import { applyTheme } from './styles/themes';
import OpenAI from 'openai';
import { v4 as uuidv4 } from 'uuid';
import 'leaflet/dist/leaflet.css';
import 'leaflet-draw/dist/leaflet.draw.css';
import 'leaflet-draw';

// Component to trigger draw mode programmatically
const DrawModeController: React.FC<{ isDrawingMode: boolean; onDrawCreated: (e: any) => void }> = ({ isDrawingMode, onDrawCreated }) => {
  const map = useMap();

  useEffect(() => {
    if (isDrawingMode && map) {
      // Enable rectangle drawing using window.L
      const L = (window as any).L;
      const drawControl = new L.Draw.Rectangle(map, {
        shapeOptions: {
          color: '#ff0000',
          weight: 2
        },
        showArea: false, // Disable buggy tooltip
        metric: false    // Disable metric measurements
      });
      drawControl.enable();

      const handleDrawCreated = (e: any) => {
        onDrawCreated(e);
        map.off('draw:created', handleDrawCreated);
      };

      map.on('draw:created', handleDrawCreated);

      return () => {
        if (drawControl) {
          drawControl.disable();
        }
        map.off('draw:created', handleDrawCreated);
      };
    }
  }, [isDrawingMode, map, onDrawCreated]);

  return null;
};

function App() {
  const [apiKey, setApiKey] = useState('');
  const [googlePlacesApiKey, setGooglePlacesApiKey] = useState('');
  const [model, setModel] = useState('gpt-4o');
  const [scriptTone, setScriptTone] = useState('Professional');
  const [showSettings, setShowSettings] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchArea, setSearchArea] = useState<any>(null);
  const [statusMessage, setStatusMessage] = useState('Initializing...');
  const [debugInfo, setDebugInfo] = useState<string[]>([]);
  const [dbReady, setDbReady] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [conversationTurns, setConversationTurns] = useState<ConversationTurn[]>([]);
  const [theme, setTheme] = useState('classic-grey');
  const [showFileMenu, setShowFileMenu] = useState(false);
  const [showHelpMenu, setShowHelpMenu] = useState(false);
  const [debugCollapsed, setDebugCollapsed] = useState(false);
  const [leadsCollapsed, setLeadsCollapsed] = useState(false);

  const allLeads = useLiveQuery(() => db.leads.toArray(), []) || [];

  const addDebug = (msg: string) => {
    console.log(msg);
    setDebugInfo(prev => [...prev, `${new Date().toLocaleTimeString()}: ${msg}`].slice(-10));
  };

  const addTestData = async () => {
    addDebug('Adding test Seattle data...');
    const testLeads: Lead[] = [
      {
        id: uuidv4(),
        business_name: 'Pike Place Coffee',
        business_type: 'Cafe',
        phone_number: '(206) 555-0101',
        address_line1: '1234 Pike St',
        city: 'Seattle',
        state: 'WA',
        zip: '98101',
        lat: 47.6097,
        lng: -122.3331,
        notes: '',
        status: 'NotContacted' as const,
        already_dialed: false,
        last_contacted_at: null,
        next_follow_up_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: uuidv4(),
        business_name: 'Seattle Auto Repair',
        business_type: 'Auto Service',
        phone_number: '(206) 555-0102',
        address_line1: '5678 Aurora Ave',
        city: 'Seattle',
        state: 'WA',
        zip: '98103',
        lat: 47.6205,
        lng: -122.3493,
        notes: '',
        status: 'NotContacted' as const,
        already_dialed: false,
        last_contacted_at: null,
        next_follow_up_at: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];
    await db.leads.bulkAdd(testLeads);
    addDebug('✅ Test data added!');
  };

  useEffect(() => {
    const init = async () => {
      addDebug('🚀 Starting app initialization...');
      const dbSuccess = await initializeDatabase();
      if (dbSuccess) {
        addDebug('✅ Database ready');
        setDbReady(true);
        await loadApiKey();
        setStatusMessage('Ready');
      } else {
        addDebug('❌ Database failed to initialize');
        setStatusMessage('Database Error - Check debug log');
        setDbReady(false);
      }
    };
    init();
  }, []);

  const loadApiKey = async () => {
    try {
      const settings = await db.settings.get('default');
      if (settings) {
        // DEBUG: Show settings status
        console.log('Settings loaded from database:', {
          hasOpenAIKey: !!settings.openai_api_key,
          hasGooglePlacesKey: !!settings.google_places_api_key,
          googlePlacesKeyLength: settings.google_places_api_key?.length || 0,
          googlePlacesEnabled: settings.google_places_enabled,
          overpassEnabled: settings.overpass_enabled,
        });

        if (settings.openai_api_key) {
          setApiKey(settings.openai_api_key);
          addDebug('🔑 Loaded OpenAI API key');
        } else {
          addDebug('⚠️ No OpenAI API key in database');
        }

        if (settings.google_places_api_key) {
          setGooglePlacesApiKey(settings.google_places_api_key);
          addDebug('🔑 Loaded Google Places API key');
        } else {
          addDebug('⚠️ No Google Places API key in database');
          // Only show alert once to avoid duplicate alerts in StrictMode
          if (!sessionStorage.getItem('api-key-alert-shown')) {
            sessionStorage.setItem('api-key-alert-shown', 'true');
            alert('Google Places API key not found! Please add it in Settings.');
          }
        }
        if (settings.openai_model) {
          setModel(settings.openai_model);
        }
        if (settings.script_tone) {
          setScriptTone(settings.script_tone);
        }
        if (settings.theme) {
          setTheme(settings.theme);
          applyTheme(settings.theme);
        } else {
          applyTheme('classic-grey');
        }
        addDebug('✅ All settings loaded from database');
      } else {
        applyTheme('classic-grey');
        addDebug('ℹ️ No saved settings found - using defaults');
      }
    } catch (error: any) {
      addDebug(`⚠️ Failed to load settings: ${error.message}`);
    }
  };

  const saveApiKey = async () => {
    try {
      // Use put() instead of update() to create or update the record
      await db.settings.put({
        id: 'default',
        openai_api_key: apiKey,
        google_places_api_key: googlePlacesApiKey,
        openai_model: model,
        script_tone: scriptTone as 'Friendly' | 'Professional' | 'Concise' | 'Casual' | 'Formal',
        google_places_enabled: true,
        overpass_enabled: true,
        theme: theme,
      });
      setShowSettings(false);
      setStatusMessage('✅ Settings saved successfully!');
      addDebug('💾 Settings saved to database');
    } catch (error: any) {
      addDebug(`❌ Failed to save settings: ${error.message}`);
      setStatusMessage('Error saving settings');
    }
  };

  const exportSettings = async () => {
    try {
      const settings = await db.settings.get('default');
      if (!settings) {
        alert('No settings to export');
        return;
      }

      const preset = {
        version: '1.0',
        exported_at: new Date().toISOString(),
        settings: {
          openai_api_key: apiKey,
          google_places_api_key: googlePlacesApiKey,
          openai_model: model,
          script_tone: scriptTone,
          theme: theme,
        }
      };

      const blob = new Blob([JSON.stringify(preset, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `leadmap-settings-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);

      addDebug('📥 Settings exported successfully');
      setStatusMessage('Settings exported');
    } catch (error: any) {
      addDebug(`❌ Export failed: ${error.message}`);
      alert('Failed to export settings');
    }
  };

  const importSettings = async () => {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';

      input.onchange = async (e: any) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (event) => {
          try {
            const preset = JSON.parse(event.target?.result as string);

            if (!preset.settings) {
              throw new Error('Invalid preset file format');
            }

            // Load settings from preset
            if (preset.settings.openai_api_key) setApiKey(preset.settings.openai_api_key);
            if (preset.settings.google_places_api_key) setGooglePlacesApiKey(preset.settings.google_places_api_key);
            if (preset.settings.openai_model) setModel(preset.settings.openai_model);
            if (preset.settings.script_tone) setScriptTone(preset.settings.script_tone);
            if (preset.settings.theme) {
              setTheme(preset.settings.theme);
              applyTheme(preset.settings.theme);
            }

            addDebug('📤 Settings imported successfully');
            setStatusMessage('Settings imported - click Save to apply');
          } catch (error: any) {
            addDebug(`❌ Import failed: ${error.message}`);
            alert('Failed to import settings: Invalid file format');
          }
        };
        reader.readAsText(file);
      };

      input.click();
    } catch (error: any) {
      addDebug(`❌ Import failed: ${error.message}`);
    }
  };

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    applyTheme(newTheme);
    addDebug(`🎨 Theme changed to: ${newTheme}`);
  };

  const exportLeads = async () => {
    try {
      const leads = await db.leads.toArray();
      if (leads.length === 0) {
        alert('No leads to export');
        return;
      }

      const data = {
        version: '1.0',
        exported_at: new Date().toISOString(),
        total_leads: leads.length,
        leads: leads,
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `leadfind-export-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);

      addDebug(`📥 Exported ${leads.length} leads`);
      setStatusMessage(`Exported ${leads.length} leads`);
      setShowFileMenu(false);
    } catch (error: any) {
      addDebug(`❌ Export failed: ${error.message}`);
      alert('Failed to export leads');
    }
  };

  const importLeads = async () => {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';

      input.onchange = async (e: any) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (event) => {
          try {
            const data = JSON.parse(event.target?.result as string);

            if (!data.leads || !Array.isArray(data.leads)) {
              throw new Error('Invalid leads file format');
            }

            await db.leads.bulkAdd(data.leads);
            addDebug(`📤 Imported ${data.leads.length} leads`);
            setStatusMessage(`Imported ${data.leads.length} leads`);
            setShowFileMenu(false);
          } catch (error: any) {
            addDebug(`❌ Import failed: ${error.message}`);
            alert('Failed to import leads: ' + error.message);
          }
        };
        reader.readAsText(file);
      };

      input.click();
    } catch (error: any) {
      addDebug(`❌ Import failed: ${error.message}`);
    }
  };

  const clearAllLeads = async () => {
    if (confirm(`Are you sure you want to delete all ${allLeads.length} leads? This cannot be undone.`)) {
      try {
        await db.leads.clear();
        addDebug('🗑️ All leads cleared');
        setStatusMessage('All leads deleted');
        setShowFileMenu(false);
      } catch (error: any) {
        addDebug(`❌ Failed to clear leads: ${error.message}`);
        alert('Failed to clear leads');
      }
    }
  };

  const [isDrawingMode, setIsDrawingMode] = useState(false);

  const onDrawCreated = (e: any) => {
    const layer = e.layer;
    const bounds = layer.getBounds();

    setSearchArea({
      north: bounds.getNorth(),
      south: bounds.getSouth(),
      east: bounds.getEast(),
      west: bounds.getWest(),
      center: bounds.getCenter(),
    });

    setStatusMessage('✅ Area selected! Now click "SEARCH FOR LEADS" button.');
    setIsDrawingMode(false);
    addDebug('✓ Rectangle drawn! Ready to search.');
  };

  const searchForLeads = async () => {
    addDebug('🔍 Search started');
    addDebug(`Search Area: ${searchArea ? 'Set' : 'Not set'}`);

    if (!searchArea) {
      alert('Please draw a rectangle on the map to select a search area.');
      return;
    }

    // Check if at least one API source is configured
    const settings = await db.settings.get('default');
    if (!settings) {
      alert('Settings not found. Please configure API keys in Settings.');
      setShowSettings(true);
      return;
    }

    const hasGooglePlaces = settings.google_places_api_key && settings.google_places_enabled !== false;
    const hasOverpass = settings.overpass_enabled !== false;

    if (!hasGooglePlaces && !hasOverpass) {
      alert('Please configure at least one API source in Settings (Google Places recommended).');
      setShowSettings(true);
      return;
    }

    setIsSearching(true);
    setStatusMessage('Initializing multi-source search...');

    try {
      addDebug('🚀 Starting multi-source lead search...');

      // Import and use the lead orchestrator
      const { leadOrchestrator } = await import('./services/leadOrchestrator');

      // Search with progress updates
      const result = await leadOrchestrator.searchLeads(
        searchArea,
        settings,
        (message: string) => {
          addDebug(message);
          setStatusMessage(message);
        }
      );

      addDebug(`🎯 Search complete: ${result.totalFound} total, ${result.totalAfterDedup} after dedup`);

      if (result.errors.length > 0) {
        addDebug(`⚠️ Errors from: ${result.errors.map((e) => e.source).join(', ')}`);
      }

      if (result.leads.length === 0) {
        setStatusMessage('No leads found in this area.');
        addDebug('⚠️ No leads found after filtering and deduplication');
        setIsSearching(false);
        return;
      }

      // Save leads to database
      const now = new Date().toISOString();
      const leadsToAdd: Lead[] = result.leads.map((business) => ({
        id: uuidv4(),
        business_name: business.business_name,
        business_type: business.business_type,
        phone_number: business.phone_number || '',
        address_line1: business.address_line1,
        city: business.city || '',
        state: business.state || '',
        zip: business.zip,
        lat: business.lat,
        lng: business.lng,
        website_url: business.website_url,
        notes: business.notes || '',
        status: 'NotContacted' as const,
        already_dialed: false,
        last_contacted_at: null,
        next_follow_up_at: null,
        created_at: now,
        updated_at: now,
        // New fields
        data_source: business.data_source,
        data_quality_score: business.data_quality_score,
        external_id: business.external_id,
        raw_categories: business.raw_categories,
        // Scraped website data
        scraped_emails: (business as any).scraped_emails,
        scraped_phones: (business as any).scraped_phones,
        facebook_url: (business as any).facebook_url,
        instagram_url: (business as any).instagram_url,
        twitter_url: (business as any).twitter_url,
        linkedin_url: (business as any).linkedin_url,
        has_contact_form: (business as any).has_contact_form,
        business_hours: (business as any).business_hours,
      }));

      addDebug(`💾 Saving ${leadsToAdd.length} leads to database...`);
      await db.leads.bulkAdd(leadsToAdd);
      addDebug('✅ Leads saved successfully!');

      setStatusMessage(
        `✅ Found ${result.totalAfterDedup} unique leads! (${result.successfulSources.join(', ')})`
      );
    } catch (error: any) {
      addDebug(`❌ Error: ${error.message}`);
      console.error('Full error:', error);
      setStatusMessage('Error searching for leads: ' + error.message);
    } finally {
      setIsSearching(false);
    }
  };

  const generateScript = async (lead: Lead) => {
    if (!apiKey) {
      alert('Please configure your OpenAI API key in settings first.');
      return;
    }

    setIsGeneratingScript(true);
    setConversationTurns([]);
    addDebug('📝 Generating interactive sales script...');

    try {
      const openai = new OpenAI({
        apiKey: apiKey,
        dangerouslyAllowBrowser: true,
      });

      const prompt = `You are a sales script writer for selling AI receptionist services to small businesses.

TARGET BUSINESS (who you are CALLING):
- Name: ${lead.business_name}
- Type: ${lead.business_type}
- Phone: ${lead.phone_number}
- Location: ${lead.city}, ${lead.state}

SCRIPT REQUIREMENTS:
- Tone: ${scriptTone}
- Purpose: YOU are calling ${lead.business_name} to schedule a demo appointment
- Product: AI Receptionist that answers calls 24/7, especially after hours
- Benefits: Never miss a call, capture leads after hours, sound professional 24/7, no more voicemail
- GOAL: Schedule a quick 15-minute demo appointment to show how it works

IMPORTANT: You work for Paradime (the AI receptionist company). You are calling ${lead.business_name}. Do NOT say "I'm calling from ${lead.business_name}". Say "I'm calling for ${lead.business_name}" or use your company name.

Generate the opening pitch for this sales call. Focus on scheduling a demo appointment, not closing a sale.

Then provide 3 likely customer responses they might give, each with:
1. A short label (e.g., "Want to See Demo", "Too Busy", "Not Interested")
2. The full customer response text

Return ONLY valid JSON in this exact format:
{
  "salesRepMessage": "Your opening pitch here...",
  "customerOptions": [
    {"label": "Short label", "text": "Full customer response"},
    {"label": "Short label", "text": "Full customer response"},
    {"label": "Short label", "text": "Full customer response"}
  ]
}`;

      const completion = await openai.chat.completions.create({
        model: model,
        messages: [
          {
            role: 'system',
            content: 'You are an expert sales copywriter. Return only valid JSON, no other text.'
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.8,
        response_format: { type: 'json_object' },
      });

      const responseText = completion.choices[0]?.message?.content || '{}';
      const aiResponse: AIScriptResponse = JSON.parse(responseText);

      // Create the first turn (sales rep opening)
      const firstTurn: ConversationTurn = {
        id: uuidv4(),
        speaker: 'sales_rep',
        message: aiResponse.salesRepMessage,
        customerResponseOptions: aiResponse.customerOptions.map((opt) => ({
          id: uuidv4(),
          label: opt.label,
          text: opt.text,
        })),
      };

      setConversationTurns([firstTurn]);
      addDebug('✅ Interactive script generated');
    } catch (error: any) {
      addDebug(`❌ Script generation failed: ${error.message}`);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleCustomerResponse = async (turnId: string, responseText: string, isCustom: boolean = false) => {
    if (!selectedLead || !apiKey) return;

    // Find the turn and add customer response
    const currentTurns = [...conversationTurns];
    const turnIndex = currentTurns.findIndex((t) => t.id === turnId);

    if (turnIndex === -1) return;

    // Mark which option was selected or add custom response
    if (isCustom) {
      currentTurns[turnIndex].customResponse = responseText;
    }

    // Add customer turn
    const customerTurn: ConversationTurn = {
      id: uuidv4(),
      speaker: 'customer',
      message: responseText,
    };

    setConversationTurns([...currentTurns, customerTurn]);
    setIsGeneratingScript(true);
    addDebug('🤖 Generating your response...');

    try {
      const openai = new OpenAI({
        apiKey: apiKey,
        dangerouslyAllowBrowser: true,
      });

      // Build conversation history for context
      const conversationHistory = [...currentTurns, customerTurn]
        .map((turn) => `${turn.speaker === 'sales_rep' ? 'YOU' : 'CUSTOMER'}: ${turn.message}`)
        .join('\n\n');

      const prompt = `You are a sales script writer for selling AI receptionist services to small businesses.

TARGET BUSINESS (who you are CALLING):
- Name: ${selectedLead.business_name}
- Type: ${selectedLead.business_type}
- Phone: ${selectedLead.phone_number}
- Location: ${selectedLead.city}, ${selectedLead.state}

PRODUCT:
- AI Receptionist that answers calls 24/7, especially after hours
- Benefits: Never miss a call, capture leads while you sleep, professional voice 24/7, no more voicemail
- Tone: ${scriptTone}
- PRIMARY GOAL: Schedule a 15-minute demo appointment to show how it works

IMPORTANT: You work for Paradime (the AI receptionist company). You are calling ${selectedLead.business_name}. Do NOT say "I'm calling from ${selectedLead.business_name}".

CONVERSATION SO FAR:
${conversationHistory}

Generate the next part of the sales conversation:
1. What should the sales rep say in response? (Keep pushing toward scheduling a demo)
2. What are 3 likely things the customer might say next?

Return ONLY valid JSON in this exact format:
{
  "salesRepMessage": "Your response here...",
  "customerOptions": [
    {"label": "Short label", "text": "Full customer response"},
    {"label": "Short label", "text": "Full customer response"},
    {"label": "Short label", "text": "Full customer response"}
  ]
}`;

      const completion = await openai.chat.completions.create({
        model: model,
        messages: [
          {
            role: 'system',
            content: 'You are an expert sales copywriter. Return only valid JSON, no other text.'
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.8,
        response_format: { type: 'json_object' },
      });

      const responseText = completion.choices[0]?.message?.content || '{}';
      const aiResponse: AIScriptResponse = JSON.parse(responseText);

      // Add sales rep turn
      const salesRepTurn: ConversationTurn = {
        id: uuidv4(),
        speaker: 'sales_rep',
        message: aiResponse.salesRepMessage,
        customerResponseOptions: aiResponse.customerOptions.map((opt) => ({
          id: uuidv4(),
          label: opt.label,
          text: opt.text,
        })),
      };

      setConversationTurns([...currentTurns, customerTurn, salesRepTurn]);
      addDebug('✅ Response generated');
    } catch (error: any) {
      addDebug(`❌ Failed to generate response: ${error.message}`);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleSelectResponse = (turnId: string, optionId: string) => {
    const turn = conversationTurns.find((t) => t.id === turnId);
    if (!turn || !turn.customerResponseOptions) return;

    const selectedOption = turn.customerResponseOptions.find((opt) => opt.id === optionId);
    if (!selectedOption) return;

    handleCustomerResponse(turnId, selectedOption.text, false);
  };

  const handleCustomResponse = (turnId: string, customText: string) => {
    handleCustomerResponse(turnId, customText, true);
  };

  return (
    <div className="flex flex-col h-screen" style={{ margin: 0, padding: 0, width: '100%', height: '100%' }}>
      {/* Title Bar */}
      <div className="xp-title-bar">
        <span>Monroe Beta - A PARADIME TECHNOLOGY PRODUCTION</span>
        <div className="flex gap-1">
          <button className="xp-title-button">_</button>
          <button className="xp-title-button">□</button>
          <button className="xp-title-button">×</button>
        </div>
      </div>

      {/* Menu Bar */}
      <div className="xp-menu-bar">
        <div className="xp-menu-item" style={{ position: 'relative' }} onClick={() => { setShowFileMenu(!showFileMenu); setShowHelpMenu(false); }}>
          File
          {showFileMenu && (
            <div style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              background: 'var(--xp-white)',
              border: '2px solid var(--xp-shadow)',
              boxShadow: '2px 2px 4px rgba(0,0,0,0.3)',
              minWidth: '180px',
              zIndex: 1000,
            }}>
              <div className="xp-menu-dropdown-item" onClick={(e) => { e.stopPropagation(); exportLeads(); }}>
                📥 Export Leads
              </div>
              <div className="xp-menu-dropdown-item" onClick={(e) => { e.stopPropagation(); importLeads(); }}>
                📤 Import Leads
              </div>
              <div style={{ borderTop: '1px solid #ccc', margin: '2px 0' }}></div>
              <div className="xp-menu-dropdown-item" onClick={(e) => { e.stopPropagation(); clearAllLeads(); }}>
                🗑️ Clear All Leads
              </div>
            </div>
          )}
        </div>
        <div className="xp-menu-item" onClick={() => { setShowSettings(true); setShowFileMenu(false); setShowHelpMenu(false); }}>
          Tools
        </div>
        <div className="xp-menu-item" style={{ position: 'relative' }} onClick={() => { setShowHelpMenu(!showHelpMenu); setShowFileMenu(false); }}>
          Help
          {showHelpMenu && (
            <div style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              background: 'var(--xp-white)',
              border: '2px solid var(--xp-shadow)',
              boxShadow: '2px 2px 4px rgba(0,0,0,0.3)',
              minWidth: '180px',
              zIndex: 1000,
            }}>
              <div className="xp-menu-dropdown-item" onClick={(e) => { e.stopPropagation(); alert('Monroe Beta v1.0\n\nA PARADIME TECHNOLOGY PRODUCTION\n\nAI-powered lead generation and sales automation tool.'); setShowHelpMenu(false); }}>
                ℹ️ About
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Toolbar */}
      <div className="xp-toolbar">
        <button className="xp-tool-button" onClick={() => setShowSettings(true)} title="Settings">⚙</button>
        <div className="xp-separator"></div>
        <button
          className="xp-tool-button"
          onClick={searchForLeads}
          disabled={isSearching || !searchArea}
          title="Search for Leads"
        >
          🔍
        </button>
        <div className="xp-separator"></div>
        <span className="text-xs px-2">{allLeads.length} leads</span>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden" style={{ gap: '4px' }}>
        {/* Left: Map Panel */}
        <div className="flex-1 xp-panel">
          <div className="xp-group-box" style={{ height: '100%', margin: 0 }}>
            <div className="xp-group-title">Geographic Search Area</div>
            <div className="xp-well" style={{ height: 'calc(100% - 16px)' }}>
              <MapContainer
                center={[39.8283, -98.5795]}
                zoom={4}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; OpenStreetMap'
                />
                <FeatureGroup>
                  <DrawModeController isDrawingMode={isDrawingMode} onDrawCreated={onDrawCreated} />
                </FeatureGroup>
              </MapContainer>
            </div>
          </div>
        </div>

        {/* Right: Leads Panel */}
        <div style={{ width: '320px' }} className="flex flex-col gap-1">
          {/* Actions Group */}
          <div className="xp-panel">
            <div className="xp-group-box" style={{ margin: 0 }}>
              <div className="xp-group-title">Actions</div>
              <div className="flex flex-col gap-2">
                <div style={{
                  padding: '12px',
                  background: 'var(--xp-white)',
                  border: '2px solid var(--xp-shadow)',
                  textAlign: 'center',
                  fontSize: '11px'
                }}>
                  {searchArea ? (
                    <div>
                      <div style={{ fontWeight: 'bold', color: 'var(--xp-black)', marginBottom: '4px' }}>
                        ✓ AREA SELECTED
                      </div>
                      <div style={{ fontSize: '10px', color: 'var(--xp-black)' }}>
                        Ready to search!
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{ fontWeight: 'bold', color: 'var(--xp-black)', marginBottom: '8px' }}>
                        STEP 1: SELECT AREA
                      </div>
                      <button
                        className="xp-button"
                        onClick={() => {
                          setIsDrawingMode(true);
                          addDebug('🖱️ Click anywhere on map, hold and drag to draw rectangle');
                          setStatusMessage('🖱️ DRAWING MODE: Click on the map, hold mouse button, drag to make a rectangle, then release');
                        }}
                        style={{
                          width: '100%',
                          padding: '12px',
                          fontSize: '13px',
                          fontWeight: 'bold',
                          background: isDrawingMode ? '#ff4444' : '#ffc107',
                          color: '#000'
                        }}
                      >
                        {isDrawingMode ? '🟥 DRAWING...' : '📍 DRAW RECTANGLE ON MAP'}
                      </button>
                      <div style={{ fontSize: '9px', color: '#856404', marginTop: '6px' }}>
                        {isDrawingMode ? '👆 Now click and drag on the map above' : 'Click this button first, then draw on the map'}
                      </div>
                    </div>
                  )}
                </div>

                <button className="xp-button w-full" onClick={() => setShowSettings(true)}>
                  ⚙️ Configure Settings
                </button>
                <button
                  className="xp-button w-full"
                  onClick={searchForLeads}
                  disabled={isSearching || !searchArea}
                  style={{
                    background: searchArea && !isSearching ? '#28a745' : undefined,
                    color: searchArea && !isSearching ? '#fff' : undefined,
                    fontWeight: searchArea ? 'bold' : undefined,
                    fontSize: searchArea ? '12px' : '11px'
                  }}
                >
                  {isSearching ? '⏳ Searching...' : searchArea ? '🔍 STEP 2: SEARCH FOR LEADS' : '🔍 Search for Leads'}
                </button>
                <button className="xp-button w-full" onClick={addTestData} style={{ fontSize: '10px' }}>
                  🧪 Add Test Data
                </button>
                <button
                  className="xp-button w-full"
                  onClick={async () => {
                    try {
                      await db.leads.clear();
                      addDebug('🗑️ Leads cleared');
                    } catch (err) {
                      addDebug(`❌ Clear failed: ${(err as Error).message}`);
                    }
                  }}
                  style={{ fontSize: '10px' }}
                >
                  🗑️ Clear Leads
                </button>
                <button
                  className="xp-button w-full"
                  onClick={async () => {
                    if (confirm('This will delete ALL data and restart the app. Continue?')) {
                      try {
                        // Try to delete the database first
                        await db.delete();
                        addDebug('💥 Database deleted');
                      } catch (err) {
                        addDebug(`⚠️ DB delete failed (this is okay): ${(err as Error).message}`);
                      }
                      // Force reload
                      addDebug('🔄 Restarting app...');
                      setTimeout(() => window.location.reload(), 500);
                    }
                  }}
                  style={{ fontSize: '10px', background: '#ff6b6b' }}
                >
                  💥 Reset Everything
                </button>
              </div>
            </div>
          </div>

          {/* Debug Panel */}
          {debugInfo.length > 0 && (
            <div className="xp-panel">
              <div className="xp-group-box" style={{ margin: 0 }}>
                <div className="xp-group-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }} onClick={() => setDebugCollapsed(!debugCollapsed)}>
                  <span>Debug Log</span>
                  <span style={{ fontSize: '10px' }}>{debugCollapsed ? '▶' : '▼'}</span>
                </div>
                {!debugCollapsed && (
                  <div style={{ fontSize: '9px', fontFamily: 'monospace', padding: '4px', maxHeight: '120px', overflow: 'auto', background: 'var(--xp-white)', color: 'var(--xp-black)', border: '1px solid var(--xp-shadow)' }}>
                    {debugInfo.map((msg, i) => (
                      <div key={i}>{msg}</div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Leads List */}
          <div className={`xp-panel flex flex-col overflow-hidden ${leadsCollapsed ? '' : 'flex-1'}`}>
            <div className="xp-group-box" style={{ height: '100%', margin: 0, display: 'flex', flexDirection: 'column' }}>
              <div className="xp-group-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }} onClick={() => setLeadsCollapsed(!leadsCollapsed)}>
                <span>Leads Database ({allLeads.length})</span>
                <span style={{ fontSize: '10px' }}>{leadsCollapsed ? '▶' : '▼'}</span>
              </div>
              {!leadsCollapsed && (<div className="xp-listview xp-scrollbar flex-1">
                {allLeads.length === 0 ? (
                  <div style={{ padding: '16px', textAlign: 'center', color: '#808080' }}>
                    No leads found.<br/><br/>
                    1. Configure API key in Tools menu<br/>
                    2. Draw rectangle on map<br/>
                    3. Click Search for Leads
                  </div>
                ) : (
                  allLeads.map((lead) => (
                    <div
                      key={lead.id}
                      className="xp-listview-item"
                      onClick={() => {
                        setSelectedLead(lead);
                        setConversationTurns([]);
                      }}
                      style={{
                        cursor: 'pointer',
                        opacity: lead.already_dialed ? 0.5 : 1,
                        background: lead.already_dialed ? 'linear-gradient(to bottom, #e8e8e8, #d8d8d8)' : undefined,
                      }}
                    >
                      <div style={{ fontWeight: 'bold', marginBottom: '2px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        {lead.already_dialed && <span style={{ fontSize: '10px' }}>✓</span>}
                        {lead.business_name}
                        {lead.data_source && (
                          <span
                            style={{
                              fontSize: '8px',
                              padding: '1px 4px',
                              borderRadius: '3px',
                              background:
                                lead.data_source === 'google_places' ? '#90ee90' :
                                lead.data_source === 'overpass' ? '#d3d3d3' :
                                '#ffcccb',
                              color: '#000',
                            }}
                          >
                            {lead.data_source === 'google_places' ? 'Google' :
                             lead.data_source === 'overpass' ? 'OSM' :
                             'AI'}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '10px', color: '#404040', marginBottom: '2px' }}>{lead.business_type}</div>
                      <div style={{ fontSize: '10px', marginBottom: '1px' }}>📞 {lead.phone_number}</div>
                      <div style={{ fontSize: '10px', color: '#404040' }}>📍 {lead.city}, {lead.state}</div>
                    </div>
                  ))
                )}
              </div>)}
            </div>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="xp-status-bar">
        <div className="xp-status-panel">{statusMessage}</div>
        <div className="xp-status-panel" style={{ flex: '0 0 120px' }}>
          {searchArea ? 'Area Selected' : 'No Area'}
        </div>
        <div className="xp-status-panel" style={{ flex: '0 0 100px' }}>
          {apiKey ? 'API Ready' : 'No API Key'}
        </div>
        <div className="xp-status-panel" style={{ flex: '0 0 100px', background: dbReady ? '#90ee90' : '#ff6b6b', color: '#000' }}>
          {dbReady ? 'DB Ready' : 'DB Error'}
        </div>
        <div className="xp-status-panel" style={{ flex: 1, fontSize: '9px', fontStyle: 'italic', color: '#606060', textAlign: 'right', paddingRight: '8px' }}>
          A PARADIME TECHNOLOGY PRODUCTION
        </div>
      </div>

      {/* Settings Dialog */}
      {showSettings && (
        <div className="fixed inset-0 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.3)', zIndex: 1000 }}>
          <div className="xp-window" style={{ width: '520px', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
            <div className="xp-title-bar">
              <span>Settings</span>
              <div className="flex gap-1">
                <button className="xp-title-button" onClick={() => setShowSettings(false)}>×</button>
              </div>
            </div>
            <div style={{ padding: '12px', overflow: 'auto', flex: 1 }}>
              {/* Lead Generation APIs */}
              <div className="xp-group-box">
                <div className="xp-group-title">Lead Generation APIs</div>

                <div className="xp-field">
                  <label className="xp-label" style={{ fontWeight: 'bold' }}>Google Places API Key:</label>
                  <input
                    type="password"
                    className="xp-input w-full"
                    value={googlePlacesApiKey}
                    onChange={(e) => setGooglePlacesApiKey(e.target.value)}
                    placeholder="Enter Google Places API key..."
                  />
                  <div style={{ fontSize: '9px', color: '#606060', marginTop: '2px' }}>
                    Best quality. Get key at: cloud.google.com/maps-platform
                  </div>
                </div>

                <div className="xp-field">
                  <div style={{ fontSize: '10px', padding: '6px', background: 'var(--xp-white)', border: '1px solid var(--xp-shadow)', color: 'var(--xp-black)' }}>
                    ✓ OpenStreetMap (fallback source, always available, no key needed)
                  </div>
                </div>
              </div>

              {/* OpenAI for Scripts */}
              <div className="xp-group-box" style={{ marginTop: '8px' }}>
                <div className="xp-group-title">OpenAI (Sales Scripts Only)</div>
                <div className="xp-field">
                  <label className="xp-label">API Key:</label>
                  <input
                    type="password"
                    className="xp-input w-full"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="sk-..."
                  />
                </div>
                <div className="xp-field">
                  <label className="xp-label">Model:</label>
                  <select
                    className="xp-select w-full"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                  >
                    <option value="gpt-4o">GPT-4o (Recommended)</option>
                    <option value="gpt-4o-mini">GPT-4o Mini (Faster, Cheaper)</option>
                    <option value="gpt-4-turbo">GPT-4 Turbo</option>
                  </select>
                </div>
                <div className="xp-field">
                  <label className="xp-label">Script Tone:</label>
                  <select
                    className="xp-select w-full"
                    value={scriptTone}
                    onChange={(e) => setScriptTone(e.target.value)}
                  >
                    <option value="Professional">Professional</option>
                    <option value="Casual">Casual</option>
                    <option value="Friendly">Friendly</option>
                    <option value="Formal">Formal</option>
                  </select>
                </div>
              </div>

              {/* UI Preferences */}
              <div className="xp-group-box" style={{ marginTop: '8px' }}>
                <div className="xp-group-title">UI Preferences</div>
                <div className="xp-field">
                  <label className="xp-label">Color Theme:</label>
                  <select
                    className="xp-select w-full"
                    value={theme}
                    onChange={(e) => handleThemeChange(e.target.value)}
                  >
                    <option value="xp-blue">Windows XP Blue</option>
                    <option value="classic-grey">Classic Grey</option>
                    <option value="dark-mode">Dark Mode</option>
                    <option value="black">Black</option>
                    <option value="olive-green">Olive Green</option>
                    <option value="midnight-blue">Midnight Blue</option>
                  </select>
                </div>
              </div>

              <div style={{ fontSize: '10px', color: '#404040', margin: '8px 0' }}>
                All API keys are stored locally in IndexedDB and never sent anywhere except their respective services.
              </div>

              {/* Preset Management */}
              <div className="xp-group-box" style={{ marginTop: '8px' }}>
                <div className="xp-group-title">Settings Presets</div>
                <div style={{ fontSize: '10px', color: '#606060', marginBottom: '6px' }}>
                  Save your settings to a file for backup or sharing across devices
                </div>
                <div className="flex gap-2">
                  <button
                    className="xp-button"
                    style={{ flex: 1 }}
                    onClick={exportSettings}
                  >
                    📥 Export Settings
                  </button>
                  <button
                    className="xp-button"
                    style={{ flex: 1 }}
                    onClick={importSettings}
                  >
                    📤 Import Settings
                  </button>
                </div>
              </div>

              <div style={{
                marginTop: '16px',
                paddingTop: '12px',
                borderTop: '1px solid #d0d0d0',
                textAlign: 'center',
                fontSize: '9px',
                fontStyle: 'italic',
                color: '#808080'
              }}>
                A PARADIME TECHNOLOGY PRODUCTION
              </div>

              <div className="flex gap-2" style={{ justifyContent: 'flex-end', marginTop: '12px' }}>
                <button className="xp-button" style={{ width: '80px' }} onClick={saveApiKey}>
                  OK
                </button>
                <button className="xp-button" style={{ width: '80px' }} onClick={() => setShowSettings(false)}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lead Detail Modal */}
      {selectedLead && (
        <div className="fixed inset-0 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.3)', zIndex: 1000 }}>
          <div className="xp-window" style={{ width: '520px', maxHeight: '85vh', display: 'flex', flexDirection: 'column' }}>
            <div className="xp-title-bar">
              <span>Lead Details - {selectedLead.business_name}</span>
              <div className="flex gap-1">
                <button className="xp-title-button" onClick={() => setSelectedLead(null)}>×</button>
              </div>
            </div>
            <div style={{ padding: '12px', overflow: 'auto', flex: 1 }}>
              {/* Business Information */}
              <div className="xp-group-box">
                <div className="xp-group-title">Business Information</div>
                <div style={{ padding: '8px', fontSize: '11px' }}>
                  <div className="xp-field">
                    <label className="xp-label" style={{ fontWeight: 'bold' }}>Business Name:</label>
                    <div style={{ padding: '4px 0' }}>{selectedLead.business_name}</div>
                  </div>
                  <div className="xp-field">
                    <label className="xp-label" style={{ fontWeight: 'bold' }}>Type:</label>
                    <div style={{ padding: '4px 0' }}>{selectedLead.business_type}</div>
                  </div>
                  <div className="xp-field">
                    <label className="xp-label" style={{ fontWeight: 'bold' }}>Phone:</label>
                    <div style={{ padding: '4px 0', fontSize: '13px', fontWeight: 'bold', color: '#0066cc' }}>
                      📞 {selectedLead.phone_number}
                    </div>
                  </div>
                  <div className="xp-field">
                    <label className="xp-label" style={{ fontWeight: 'bold' }}>Address:</label>
                    <div style={{ padding: '4px 0' }}>
                      {selectedLead.address_line1}<br/>
                      {selectedLead.city}, {selectedLead.state} {selectedLead.zip}
                    </div>
                  </div>
                  <div className="xp-field">
                    <label className="xp-label" style={{ fontWeight: 'bold' }}>Coordinates:</label>
                    <div style={{ padding: '4px 0', fontSize: '10px', color: '#606060', fontFamily: 'monospace' }}>
                      {selectedLead.lat.toFixed(4)}, {selectedLead.lng.toFixed(4)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Call Tracking Section */}
              <div className="xp-group-box" style={{ marginTop: '8px' }}>
                <div className="xp-group-title">Call Tracking</div>
                <div style={{ padding: '8px' }}>
                  <button
                    className="xp-button"
                    onClick={async () => {
                      try {
                        await db.leads.update(selectedLead.id, {
                          already_dialed: !selectedLead.already_dialed,
                          updated_at: new Date().toISOString(),
                        });
                        setSelectedLead({ ...selectedLead, already_dialed: !selectedLead.already_dialed });
                        addDebug(`${selectedLead.already_dialed ? '✓' : '📞'} Lead marked as ${selectedLead.already_dialed ? 'not dialed' : 'dialed'}`);
                      } catch (error: any) {
                        addDebug(`❌ Failed to update: ${error.message}`);
                      }
                    }}
                    style={{
                      width: '100%',
                      padding: '10px',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      background: selectedLead.already_dialed ? '#ff6b6b' : '#90ee90',
                      color: selectedLead.already_dialed ? '#fff' : '#000',
                    }}
                  >
                    {selectedLead.already_dialed ? '✓ Already Dialed - Click to Unmark' : '📞 Mark as Already Dialed'}
                  </button>
                  <div style={{ fontSize: '10px', color: '#606060', textAlign: 'center', padding: '8px 0 4px' }}>
                    {selectedLead.already_dialed ? 'This number has been dialed' : 'Mark this number to skip it in future calls'}
                  </div>
                </div>
              </div>

              {/* Script Generation Section */}
              <div className="xp-group-box" style={{ marginTop: '8px' }}>
                <div className="xp-group-title">Sales Script Generator</div>
                <div style={{ padding: '8px' }}>
                  <button
                    className="xp-button"
                    onClick={() => generateScript(selectedLead)}
                    disabled={isGeneratingScript}
                    style={{
                      width: '100%',
                      padding: '10px',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      background: isGeneratingScript ? '#d4d0c8' : '#90ee90',
                      marginBottom: '8px'
                    }}
                  >
                    {isGeneratingScript ? '⏳ Generating Script...' : '📝 Generate Sales Script'}
                  </button>

                  {conversationTurns.length > 0 ? (
                    <ConversationTree
                      turns={conversationTurns}
                      isGenerating={isGeneratingScript}
                      onSelectResponse={handleSelectResponse}
                      onCustomResponse={handleCustomResponse}
                    />
                  ) : (
                    !isGeneratingScript && (
                      <div style={{ fontSize: '10px', color: '#606060', textAlign: 'center', padding: '12px' }}>
                        Click the button above to generate an interactive sales script<br/>
                        using your selected tone: <strong>{scriptTone}</strong>
                      </div>
                    )
                  )}
                </div>
              </div>

              <div style={{
                marginTop: '16px',
                paddingTop: '12px',
                borderTop: '1px solid #d0d0d0',
                textAlign: 'center',
                fontSize: '9px',
                fontStyle: 'italic',
                color: '#808080'
              }}>
                A PARADIME TECHNOLOGY PRODUCTION
              </div>

              {/* Close Button */}
              <div style={{ marginTop: '12px', textAlign: 'right' }}>
                <button
                  className="xp-button"
                  onClick={() => setSelectedLead(null)}
                  style={{ width: '100px', padding: '8px' }}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
