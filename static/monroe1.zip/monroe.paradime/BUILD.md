# Monroe Beta - Build Instructions

AI-powered lead generation and sales automation CRM

## Prerequisites

- Node.js 18+ and npm
- Git

## Platform-Specific Requirements

### Windows
- Windows 10/11
- No additional tools required for building Windows binaries

### macOS
- macOS 10.13+
- Xcode 14+ (for building macOS and iOS apps)
- Xcode Command Line Tools

### iOS
- macOS with Xcode 14+
- iOS Simulator or physical iOS device
- Apple Developer Account (for device deployment)

## Quick Start

```bash
# Clone the repository
git clone <repository-url>
cd lead-map-workspace

# Install dependencies
npm install

# Run in development mode (Electron)
npm run electron:dev
```

## Building for Production

### Windows

Build both installer and portable executable:

```bash
npm run electron:build:win
```

Output files in `release/`:
- `Monroe Beta Setup 1.0.0.exe` - NSIS installer
- `Monroe Beta 1.0.0.exe` - Portable executable

### macOS (requires macOS)

Build DMG and ZIP archives:

```bash
npm run electron:build:mac
```

Output files in `release/`:
- `Monroe Beta-1.0.0.dmg` - DMG installer
- `Monroe Beta-1.0.0-mac.zip` - ZIP archive

**Note:** macOS builds can only be created on macOS due to code signing requirements.

### iOS (requires macOS with Xcode)

1. Build the web assets:
```bash
npm run build
```

2. Sync to iOS project:
```bash
npx cap sync ios
```

3. Open in Xcode:
```bash
npx cap open ios
```

4. In Xcode:
   - Select your development team
   - Choose a target device or simulator
   - Click Run (⌘R) to build and launch

For App Store distribution:
- Configure signing certificates in Xcode
- Archive the app (Product > Archive)
- Upload to App Store Connect

## Configuration

### API Keys

The app requires API keys for full functionality:

1. **Google Places API (New)**
   - Enable "Places API (New)" in Google Cloud Console
   - Create API key with Places API (New) enabled
   - Add key in app Settings panel

2. **OpenAI API** (optional for AI features)
   - Get API key from https://platform.openai.com/
   - Add key in app Settings panel

### Environment Setup

No environment variables needed - all configuration is done in-app via the Settings panel.

## Development

### Project Structure

```
lead-map-workspace/
├── src/                    # React/TypeScript source code
│   ├── services/          # API services (Google Places, Overpass, etc.)
│   ├── db/                # IndexedDB database layer
│   ├── utils/             # Utilities and helpers
│   └── types/             # TypeScript type definitions
├── electron/              # Electron main process
├── dist/                  # Built web assets (generated)
├── ios/                   # iOS/Capacitor project (generated)
└── release/              # Built desktop apps (generated)
```

### Available Scripts

- `npm run dev` - Start Vite dev server
- `npm run build` - Build web assets for production
- `npm run electron:dev` - Run Electron in development mode
- `npm run electron:build` - Build for current platform
- `npm run electron:build:win` - Build Windows installers
- `npm run electron:build:mac` - Build macOS apps (macOS only)
- `npx cap sync ios` - Sync web assets to iOS

### Tech Stack

- **Desktop:** Electron 39
- **Mobile:** Capacitor 8
- **Frontend:** React 19, TypeScript, Vite
- **UI:** Custom Windows XP theme, Tailwind CSS
- **Mapping:** Leaflet, React Leaflet
- **Database:** IndexedDB via Dexie
- **APIs:** Google Places API (New), OpenStreetMap/Overpass

## Troubleshooting

### Windows Build Issues

**Error: "Cannot create symbolic link"**
- This is usually a permission issue with Windows Developer Mode
- Solution: The build configuration is set to skip code signing (`signAndEditExecutable: false`)
- The unsigned binaries will work fine for distribution

### macOS Build from Windows

**Error: "Build for macOS is supported only on macOS"**
- Cross-compilation from Windows to macOS is not supported by electron-builder
- Solution: Use a macOS machine or CI/CD service (GitHub Actions) for macOS builds

### iOS Build Issues

**Error: "Xcode project not found"**
- Make sure you've run `npm run build` and `npx cap add ios`
- Sync assets with `npx cap sync ios`

**Error: "No signing certificate"**
- You need an Apple Developer account
- Configure signing in Xcode under Signing & Capabilities

## Distribution

### Windows
- Distribute the `.exe` files from `release/`
- No code signing required for testing
- For production, consider code signing with a certificate

### macOS
- Notarize the app for distribution outside the App Store
- See Apple's notarization documentation

### iOS
- Distribute via TestFlight (beta)
- Submit to App Store (production)
- Or use Ad-Hoc/Enterprise distribution

## License

Proprietary - PARADIME TECHNOLOGY

## Support

For issues and questions, contact the development team.
