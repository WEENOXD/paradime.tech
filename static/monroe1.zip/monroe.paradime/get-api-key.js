const Dexie = require('dexie');

async function getAPIKey() {
  const db = new Dexie('LeadMapDatabase');

  db.version(4).stores({
    leads: 'id, business_name, business_type, city, state, status, created_at, updated_at, phone_number, data_source, external_id, has_contact_form, already_dialed',
    settings: 'id'
  });

  try {
    await db.open();
    const settings = await db.settings.get('default');

    if (settings && settings.google_places_api_key) {
      console.log('Google Places API Key:', settings.google_places_api_key);

      // Test the API
      const axios = require('axios');
      const testUrl = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json';

      console.log('\nTesting API with Phoenix, AZ coordinates...');
      const response = await axios.get(testUrl, {
        params: {
          location: '33.4484,-112.0740',
          radius: 5000,
          type: 'restaurant',
          key: settings.google_places_api_key,
        },
      });

      console.log('\n=== API RESPONSE ===');
      console.log('Status:', response.data.status);
      console.log('Error Message:', response.data.error_message || 'None');
      console.log('Results:', response.data.results?.length || 0);

      if (response.data.results && response.data.results.length > 0) {
        console.log('\nFirst result:');
        console.log(JSON.stringify(response.data.results[0], null, 2));
      }

    } else {
      console.log('No API key found in database');
    }

    db.close();
  } catch (error) {
    console.error('Error:', error.message);
    if (error.response) {
      console.error('Response:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

getAPIKey();
