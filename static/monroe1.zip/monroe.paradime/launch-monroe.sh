#!/bin/bash

# Launch Monroe Beta - macOS Script
# Navigate to the application directory and start the Electron app

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Change to the application directory
cd "$SCRIPT_DIR"

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build the application if dist folder doesn't exist
if [ ! -d "dist" ]; then
    echo "Building application..."
    npm run build
fi

# Launch the Electron app
echo "Starting Monroe Beta..."
npx electron .