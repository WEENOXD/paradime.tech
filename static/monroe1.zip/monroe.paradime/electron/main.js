const { app, BrowserWindow, session } = require('electron');
const path = require('path');
const fs = require('fs');

// Disable Chromium's quota storage to prevent database errors
app.commandLine.appendSwitch('disable-features', 'QuotaStorage,StorageService');
app.commandLine.appendSwitch('disable-site-isolation-trials');
app.commandLine.appendSwitch('disable-web-security');
app.commandLine.appendSwitch('allow-file-access-from-files');
app.commandLine.appendSwitch('ignore-certificate-errors');
// Fix quota database error by using in-memory storage for quota management
app.commandLine.appendSwitch('quota-database', 'memory');

// Clear corrupted storage on startup if flag file exists
function checkAndClearStorage() {
  const userDataPath = app.getPath('userData');
  const clearFlagPath = path.join(userDataPath, '.clear-storage');

  if (fs.existsSync(clearFlagPath)) {
    console.log('Clear storage flag found - removing corrupted data...');
    try {
      // Remove the flag file
      fs.unlinkSync(clearFlagPath);

      // Clear session storage
      const ses = session.defaultSession;
      ses.clearStorageData({
        storages: ['indexeddb', 'localstorage', 'websql', 'cachestorage']
      });

      console.log('Storage cleared successfully');
    } catch (err) {
      console.error('Error clearing storage:', err);
    }
  }
}

function createWindow() {
  // Ensure userData directory exists
  const userDataPath = app.getPath('userData');
  console.log('User Data Path:', userDataPath);

  if (!fs.existsSync(userDataPath)) {
    fs.mkdirSync(userDataPath, { recursive: true });
  }

  // Check and clear corrupted storage if needed
  checkAndClearStorage();

  const mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true,
      enableRemoteModule: false,
      sandbox: false
    },
    icon: path.join(__dirname, '../public/icon.png'),
    title: 'Monroe Beta',
    backgroundColor: '#0a0e27'
  });

  console.log('Storage path:', app.getPath('userData'));

  // Load from dev server in development, built files in production
  if (process.env.NODE_ENV === 'development') {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  // Always open DevTools for debugging
  mainWindow.webContents.openDevTools();

  // Log console messages to terminal
  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[RENDERER] ${message}`);
  });

  // Remove menu bar
  mainWindow.setMenuBarVisibility(false);
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
