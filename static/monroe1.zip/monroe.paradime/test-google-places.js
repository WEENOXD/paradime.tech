const axios = require('axios');
const fs = require('fs');

async function testGooglePlacesAPI() {
  // Read API key from settings
  const dbPath = 'C:\\Users\\Linse\\AppData\\Roaming\\leadfind-beta';
  console.log('Reading settings from:', dbPath);

  // Test coordinates (Phoenix, AZ area)
  const lat = 33.4484;
  const lng = -112.0740;
  const radius = 5000; // 5km
  const type = 'restaurant';

  // You'll need to manually paste your Google Places API key here
  const apiKey = 'YOUR_API_KEY_HERE';

  console.log('\n=== Testing Google Places API ===');
  console.log('Location:', lat, lng);
  console.log('Radius:', radius, 'm');
  console.log('Type:', type);
  console.log('API Key:', apiKey.substring(0, 10) + '...\n');

  try {
    // Test Nearby Search
    const nearbyUrl = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
    console.log('Testing Nearby Search...');
    console.log('URL:', nearbyUrl);

    const response = await axios.get(nearbyUrl, {
      params: {
        location: `${lat},${lng}`,
        radius: radius,
        type: type,
        key: apiKey,
      },
    });

    console.log('\n=== RESPONSE ===');
    console.log('Status:', response.data.status);
    console.log('Error Message:', response.data.error_message);
    console.log('Results Count:', response.data.results?.length || 0);

    if (response.data.results && response.data.results.length > 0) {
      console.log('\n=== FIRST RESULT ===');
      const first = response.data.results[0];
      console.log(JSON.stringify(first, null, 2));

      // Test Place Details
      console.log('\n=== Testing Place Details ===');
      const detailsUrl = 'https://maps.googleapis.com/maps/api/place/details/json';
      const detailsResponse = await axios.get(detailsUrl, {
        params: {
          place_id: first.place_id,
          fields: 'place_id,name,formatted_phone_number,international_phone_number,formatted_address,address_components,geometry,types,website,business_status',
          key: apiKey,
        },
      });

      console.log('Details Status:', detailsResponse.data.status);
      console.log('\n=== PLACE DETAILS ===');
      console.log(JSON.stringify(detailsResponse.data.result, null, 2));
    }

  } catch (error) {
    console.error('\n=== ERROR ===');
    console.error('Message:', error.message);
    console.error('Response Status:', error.response?.status);
    console.error('Response Data:', JSON.stringify(error.response?.data, null, 2));
  }
}

testGooglePlacesAPI();
